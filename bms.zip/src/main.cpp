// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using std::isnan;
using std::min;
using std::max;
using namespace binary_sensor;
using namespace button;
using namespace number;
using namespace sensor;
using namespace switch_;
using namespace text_sensor;
logger::Logger *logger_logger_id;
wifi::WiFiComponent *wifi_wificomponent_id;
mdns::MDNSComponent *mdns_mdnscomponent_id;
esphome::ESPHomeOTAComponent *esphome_esphomeotacomponent_id;
safe_mode::SafeModeComponent *safe_mode_safemodecomponent_id;
ota::OTAStartTrigger *ota_otastarttrigger_id;
Automation<> *automation_id;
api::APIServer *api_apiserver_id;
using namespace api;
preferences::IntervalSyncer *preferences_intervalsyncer_id;
esp32_ble_tracker::ESP32BLETracker *esp32_ble_tracker_esp32bletracker_id;
ble_client::BLEClient *client0;
jk_bms_ble::JkBmsBle *bms0;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_2;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_3;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_5;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_4;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_6;
binary_sensor::BinarySensor *binary_sensor_binarysensor_id_7;
jk_bms_ble::JkButton *jk_bms_ble_jkbutton_id;
jk_bms_ble::JkButton *jk_bms_ble_jkbutton_id_2;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_15;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_6;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_7;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_4;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_5;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_16;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_17;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_18;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_19;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_20;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_21;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_2;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_3;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_8;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_9;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_10;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_11;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_12;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_13;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_14;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_22;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_23;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_24;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_25;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_26;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_27;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_28;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_29;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_30;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_31;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_32;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_33;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_34;
jk_bms_ble::JkNumber *jk_bms_ble_jknumber_id_35;
sensor::Sensor *sensor_sensor_id_7;
sensor::Sensor *sensor_sensor_id_8;
sensor::Sensor *sensor_sensor_id_9;
sensor::Sensor *sensor_sensor_id_10;
sensor::Sensor *sensor_sensor_id_11;
sensor::Sensor *sensor_sensor_id_12;
sensor::Sensor *sensor_sensor_id_13;
sensor::Sensor *sensor_sensor_id_14;
sensor::Sensor *sensor_sensor_id_15;
sensor::Sensor *sensor_sensor_id_16;
sensor::Sensor *sensor_sensor_id_17;
sensor::Sensor *sensor_sensor_id_18;
sensor::Sensor *sensor_sensor_id_19;
sensor::Sensor *sensor_sensor_id_20;
sensor::Sensor *sensor_sensor_id_21;
sensor::Sensor *sensor_sensor_id_22;
sensor::Sensor *sensor_sensor_id_23;
sensor::Sensor *sensor_sensor_id_24;
sensor::Sensor *sensor_sensor_id_25;
sensor::Sensor *sensor_sensor_id_26;
sensor::Sensor *sensor_sensor_id_27;
sensor::Sensor *sensor_sensor_id_28;
sensor::Sensor *sensor_sensor_id_29;
sensor::Sensor *sensor_sensor_id_30;
sensor::Sensor *sensor_sensor_id_31;
sensor::Sensor *sensor_sensor_id_32;
sensor::Sensor *sensor_sensor_id_33;
sensor::Sensor *sensor_sensor_id_34;
sensor::Sensor *sensor_sensor_id_35;
sensor::Sensor *sensor_sensor_id_36;
sensor::Sensor *sensor_sensor_id_37;
sensor::Sensor *sensor_sensor_id_38;
sensor::Sensor *sensor_sensor_id_39;
sensor::Sensor *sensor_sensor_id_40;
sensor::Sensor *sensor_sensor_id_41;
sensor::Sensor *sensor_sensor_id_42;
sensor::Sensor *sensor_sensor_id_43;
sensor::Sensor *sensor_sensor_id_44;
sensor::Sensor *sensor_sensor_id_45;
sensor::Sensor *sensor_sensor_id_46;
sensor::Sensor *sensor_sensor_id_47;
sensor::Sensor *sensor_sensor_id_48;
sensor::Sensor *sensor_sensor_id_49;
sensor::Sensor *sensor_sensor_id_50;
sensor::Sensor *sensor_sensor_id_51;
sensor::Sensor *sensor_sensor_id_52;
sensor::Sensor *sensor_sensor_id_53;
sensor::Sensor *sensor_sensor_id_54;
sensor::Sensor *sensor_sensor_id_61;
sensor::Sensor *sensor_sensor_id_62;
sensor::Sensor *sensor_sensor_id_63;
sensor::Sensor *sensor_sensor_id_64;
sensor::Sensor *sensor_sensor_id_65;
sensor::Sensor *sensor_sensor_id_67;
sensor::Sensor *sensor_sensor_id;
sensor::Sensor *sensor_sensor_id_2;
sensor::Sensor *sensor_sensor_id_3;
sensor::Sensor *sensor_sensor_id_4;
sensor::Sensor *sensor_sensor_id_5;
sensor::Sensor *sensor_sensor_id_6;
sensor::Sensor *sensor_sensor_id_55;
sensor::Sensor *sensor_sensor_id_56;
sensor::Sensor *sensor_sensor_id_58;
sensor::Sensor *sensor_sensor_id_59;
sensor::Sensor *sensor_sensor_id_60;
sensor::Sensor *sensor_sensor_id_66;
sensor::Sensor *sensor_sensor_id_68;
sensor::Sensor *sensor_sensor_id_69;
sensor::Sensor *sensor_sensor_id_70;
sensor::Sensor *sensor_sensor_id_71;
sensor::Sensor *sensor_sensor_id_72;
sensor::Sensor *sensor_sensor_id_73;
sensor::Sensor *sensor_sensor_id_74;
sensor::Sensor *sensor_sensor_id_75;
sensor::Sensor *sensor_sensor_id_76;
sensor::Sensor *sensor_sensor_id_57;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_2;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_3;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_4;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_5;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_6;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_7;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_8;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_9;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_10;
jk_bms_ble::JkSwitch *jk_bms_ble_jkswitch_id_11;
ble_client::BLEClientSwitch *ble_client_switch0;
text_sensor::TextSensor *text_sensor_textsensor_id;
text_sensor::TextSensor *text_sensor_textsensor_id_2;
esp32_ble::ESP32BLE *esp32_ble_esp32ble_id;
switch_::TurnOffAction<> *switch__turnoffaction_id;
LambdaAction<> *lambdaaction_id;
#define yield() esphome::yield()
#define millis() esphome::millis()
#define micros() esphome::micros()
#define delay(x) esphome::delay(x)
#define delayMicroseconds(x) esphome::delayMicroseconds(x)
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ========== AUTO GENERATED CODE BEGIN ===========
  // esphome:
  //   name: jk-bms
  //   comment: Monitor and control a JK-BMS v11 via bluetooth
  //   min_version: 2024.6.0
  //   project:
  //     name: syssi.esphome-jk-bms
  //     version: 2.1.0
  //   build_path: build\jk-bms
  //   friendly_name: ''
  //   area: ''
  //   platformio_options: {}
  //   includes: []
  //   libraries: []
  //   name_add_mac_suffix: false
  //   debug_scheduler: false
  App.pre_setup("jk-bms", "", "", "Monitor and control a JK-BMS v11 via bluetooth", __DATE__ ", " __TIME__, false);
  // binary_sensor:
  // button:
  // number:
  // sensor:
  // switch:
  // text_sensor:
  // logger:
  //   level: DEBUG
  //   logs:
  //     esp32_ble_tracker: INFO
  //     esp32_ble_client: INFO
  //   id: logger_logger_id
  //   baud_rate: 115200
  //   tx_buffer_size: 512
  //   deassert_rts_dtr: false
  //   hardware_uart: UART0
  logger_logger_id = new logger::Logger(115200, 512);
  logger_logger_id->set_log_level(ESPHOME_LOG_LEVEL_DEBUG);
  logger_logger_id->set_uart_selection(logger::UART_SELECTION_UART0);
  logger_logger_id->pre_setup();
  logger_logger_id->set_log_level("esp32_ble_tracker", ESPHOME_LOG_LEVEL_INFO);
  logger_logger_id->set_log_level("esp32_ble_client", ESPHOME_LOG_LEVEL_INFO);
  logger_logger_id->set_component_source("logger");
  App.register_component(logger_logger_id);
  // wifi:
  //   id: wifi_wificomponent_id
  //   domain: .local
  //   reboot_timeout: 15min
  //   power_save_mode: LIGHT
  //   fast_connect: false
  //   passive_scan: false
  //   enable_on_boot: true
  //   networks:
  //   - ssid: Nothing
  //     password: '88888888'
  //     id: wifi_wifiap_id
  //     priority: 0.0
  //   use_address: jk-bms.local
  wifi_wificomponent_id = new wifi::WiFiComponent();
  wifi_wificomponent_id->set_use_address("jk-bms.local");
  {
  wifi::WiFiAP wifi_wifiap_id = wifi::WiFiAP();
  wifi_wifiap_id.set_ssid("Nothing");
  wifi_wifiap_id.set_password("88888888");
  wifi_wifiap_id.set_priority(0.0f);
  wifi_wificomponent_id->add_sta(wifi_wifiap_id);
  }
  wifi_wificomponent_id->set_reboot_timeout(900000);
  wifi_wificomponent_id->set_power_save_mode(wifi::WIFI_POWER_SAVE_LIGHT);
  wifi_wificomponent_id->set_fast_connect(false);
  wifi_wificomponent_id->set_passive_scan(false);
  wifi_wificomponent_id->set_enable_on_boot(true);
  wifi_wificomponent_id->set_component_source("wifi");
  App.register_component(wifi_wificomponent_id);
  // mdns:
  //   id: mdns_mdnscomponent_id
  //   disabled: false
  //   services: []
  mdns_mdnscomponent_id = new mdns::MDNSComponent();
  mdns_mdnscomponent_id->set_component_source("mdns");
  App.register_component(mdns_mdnscomponent_id);
  // ota:
  // ota.esphome:
  //   platform: esphome
  //   on_begin:
  //   - then:
  //     - switch.turn_off:
  //         id: ble_client_switch0
  //       type_id: switch__turnoffaction_id
  //     - logger.log:
  //         format: BLE connection suspended for OTA update
  //         tag: main
  //         args: []
  //         level: DEBUG
  //       type_id: lambdaaction_id
  //     automation_id: automation_id
  //     trigger_id: ota_otastarttrigger_id
  //   id: esphome_esphomeotacomponent_id
  //   version: 2
  //   port: 3232
  esphome_esphomeotacomponent_id = new esphome::ESPHomeOTAComponent();
  esphome_esphomeotacomponent_id->set_port(3232);
  esphome_esphomeotacomponent_id->set_component_source("esphome.ota");
  App.register_component(esphome_esphomeotacomponent_id);
  // safe_mode:
  //   id: safe_mode_safemodecomponent_id
  //   boot_is_good_after: 1min
  //   disabled: false
  //   num_attempts: 10
  //   reboot_timeout: 5min
  safe_mode_safemodecomponent_id = new safe_mode::SafeModeComponent();
  safe_mode_safemodecomponent_id->set_component_source("safe_mode");
  App.register_component(safe_mode_safemodecomponent_id);
  if (safe_mode_safemodecomponent_id->should_enter_safe_mode(10, 300000, 60000)) return;
  ota_otastarttrigger_id = new ota::OTAStartTrigger(esphome_esphomeotacomponent_id);
  automation_id = new Automation<>(ota_otastarttrigger_id);
  // api:
  //   encryption:
  //     key: hXzjNltHkCoMcqeOsEW+WrjNojJ6Rq2T2FcBLZ74Z8c=
  //   id: api_apiserver_id
  //   port: 6053
  //   password: ''
  //   reboot_timeout: 15min
  api_apiserver_id = new api::APIServer();
  api_apiserver_id->set_component_source("api");
  App.register_component(api_apiserver_id);
  api_apiserver_id->set_port(6053);
  api_apiserver_id->set_password("");
  api_apiserver_id->set_reboot_timeout(900000);
  api_apiserver_id->set_noise_psk({133, 124, 227, 54, 91, 71, 144, 42, 12, 114, 167, 142, 176, 69, 190, 90, 184, 205, 162, 50, 122, 70, 173, 147, 216, 87, 1, 45, 158, 248, 103, 199});
  // substitutions:
  //   name: jk-bms
  //   device_description: Monitor and control a JK-BMS v11 via bluetooth
  //   external_components_source: github:syssi/esphome-jk-bms@main
  //   mac_address: c8:47:80:1e:37:66
  //   protocol_version: JK02_32S
  // esp32:
  //   board: esp32dev
  //   framework:
  //     version: 2.0.5
  //     advanced:
  //       ignore_efuse_custom_mac: false
  //     source: ~3.20005.0
  //     platform_version: platformio/espressif32@5.4.0
  //     type: arduino
  //   flash_size: 4MB
  //   variant: ESP32
  // preferences:
  //   id: preferences_intervalsyncer_id
  //   flash_write_interval: 60s
  preferences_intervalsyncer_id = new preferences::IntervalSyncer();
  preferences_intervalsyncer_id->set_write_interval(60000);
  preferences_intervalsyncer_id->set_component_source("preferences");
  App.register_component(preferences_intervalsyncer_id);
  // external_components:
  //   - source:
  //       url: https:github.com/syssi/esphome-jk-bms.git
  //       ref: main
  //       type: git
  //     refresh: 0s
  //     components: all
  // esp32_ble_tracker:
  //   scan_parameters:
  //     active: false
  //     duration: 5min
  //     interval: 320ms
  //     window: 30ms
  //     continuous: true
  //   id: esp32_ble_tracker_esp32bletracker_id
  //   ble_id: esp32_ble_esp32ble_id
  //   max_connections: 3
  esp32_ble_tracker_esp32bletracker_id = new esp32_ble_tracker::ESP32BLETracker();
  esp32_ble_tracker_esp32bletracker_id->set_component_source("esp32_ble_tracker");
  App.register_component(esp32_ble_tracker_esp32bletracker_id);
  // ble_client:
  //   mac_address: C8:47:80:1E:37:66
  //   id: client0
  //   auto_connect: true
  //   esp32_ble_id: esp32_ble_tracker_esp32bletracker_id
  client0 = new ble_client::BLEClient();
  client0->set_component_source("ble_client");
  App.register_component(client0);
  esp32_ble_tracker_esp32bletracker_id->register_client(client0);
  client0->set_address(0xC847801E3766ULL);
  client0->set_auto_connect(true);
  // jk_bms_ble:
  //   ble_client_id: client0
  //   protocol_version: JK02_32S
  //   throttle: 5s
  //   id: bms0
  //   update_interval: 5s
  bms0 = new jk_bms_ble::JkBmsBle();
  bms0->set_update_interval(5000);
  bms0->set_component_source("jk_bms_ble");
  App.register_component(bms0);
  client0->register_ble_node(bms0);
  bms0->set_throttle(5000);
  bms0->set_protocol_version(jk_bms_ble::PROTOCOL_VERSION_JK02_32S);
  // binary_sensor.jk_bms_ble:
  //   platform: jk_bms_ble
  //   balancing:
  //     name: jk-bms balancing
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id
  //     icon: mdi:battery-heart-variant
  //   charging:
  //     name: jk-bms charging
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_2
  //     icon: mdi:battery-charging
  //   discharging:
  //     name: jk-bms discharging
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_3
  //     icon: mdi:power-plug
  //   heating:
  //     name: jk-bms heating
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_4
  //     icon: mdi:radiator
  //   online_status:
  //     name: jk-bms online status
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_5
  //     entity_category: diagnostic
  //     device_class: connectivity
  //   dry_contact_1:
  //     name: jk-bms dry contact 1
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_6
  //     icon: mdi:alarm-bell
  //   dry_contact_2:
  //     name: jk-bms dry contact 2
  //     disabled_by_default: false
  //     id: binary_sensor_binarysensor_id_7
  //     icon: mdi:alarm-bell
  //   jk_bms_ble_id: bms0
  binary_sensor_binarysensor_id_2 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_2);
  binary_sensor_binarysensor_id_2->set_name("jk-bms charging");
  binary_sensor_binarysensor_id_2->set_object_id("jk-bms_charging");
  binary_sensor_binarysensor_id_2->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_2->set_icon("mdi:battery-charging");
  bms0->set_charging_binary_sensor(binary_sensor_binarysensor_id_2);
  binary_sensor_binarysensor_id_3 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_3);
  binary_sensor_binarysensor_id_3->set_name("jk-bms discharging");
  binary_sensor_binarysensor_id_3->set_object_id("jk-bms_discharging");
  binary_sensor_binarysensor_id_3->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_3->set_icon("mdi:power-plug");
  bms0->set_discharging_binary_sensor(binary_sensor_binarysensor_id_3);
  binary_sensor_binarysensor_id = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id);
  binary_sensor_binarysensor_id->set_name("jk-bms balancing");
  binary_sensor_binarysensor_id->set_object_id("jk-bms_balancing");
  binary_sensor_binarysensor_id->set_disabled_by_default(false);
  binary_sensor_binarysensor_id->set_icon("mdi:battery-heart-variant");
  bms0->set_balancing_binary_sensor(binary_sensor_binarysensor_id);
  binary_sensor_binarysensor_id_5 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_5);
  binary_sensor_binarysensor_id_5->set_name("jk-bms online status");
  binary_sensor_binarysensor_id_5->set_object_id("jk-bms_online_status");
  binary_sensor_binarysensor_id_5->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_5->set_entity_category(::ENTITY_CATEGORY_DIAGNOSTIC);
  binary_sensor_binarysensor_id_5->set_device_class("connectivity");
  bms0->set_online_status_binary_sensor(binary_sensor_binarysensor_id_5);
  binary_sensor_binarysensor_id_4 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_4);
  binary_sensor_binarysensor_id_4->set_name("jk-bms heating");
  binary_sensor_binarysensor_id_4->set_object_id("jk-bms_heating");
  binary_sensor_binarysensor_id_4->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_4->set_icon("mdi:radiator");
  bms0->set_heating_binary_sensor(binary_sensor_binarysensor_id_4);
  binary_sensor_binarysensor_id_6 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_6);
  binary_sensor_binarysensor_id_6->set_name("jk-bms dry contact 1");
  binary_sensor_binarysensor_id_6->set_object_id("jk-bms_dry_contact_1");
  binary_sensor_binarysensor_id_6->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_6->set_icon("mdi:alarm-bell");
  bms0->set_dry_contact_1_binary_sensor(binary_sensor_binarysensor_id_6);
  binary_sensor_binarysensor_id_7 = new binary_sensor::BinarySensor();
  App.register_binary_sensor(binary_sensor_binarysensor_id_7);
  binary_sensor_binarysensor_id_7->set_name("jk-bms dry contact 2");
  binary_sensor_binarysensor_id_7->set_object_id("jk-bms_dry_contact_2");
  binary_sensor_binarysensor_id_7->set_disabled_by_default(false);
  binary_sensor_binarysensor_id_7->set_icon("mdi:alarm-bell");
  bms0->set_dry_contact_2_binary_sensor(binary_sensor_binarysensor_id_7);
  // button.jk_bms_ble:
  //   platform: jk_bms_ble
  //   retrieve_settings:
  //     name: jk-bms retrieve settings
  //     disabled_by_default: false
  //     id: jk_bms_ble_jkbutton_id
  //     icon: mdi:cog
  //   retrieve_device_info:
  //     name: jk-bms retrieve device info
  //     disabled_by_default: false
  //     id: jk_bms_ble_jkbutton_id_2
  //     icon: mdi:information-variant
  //   jk_bms_ble_id: bms0
  jk_bms_ble_jkbutton_id = new jk_bms_ble::JkButton();
  jk_bms_ble_jkbutton_id->set_component_source("jk_bms_ble.button");
  App.register_component(jk_bms_ble_jkbutton_id);
  App.register_button(jk_bms_ble_jkbutton_id);
  jk_bms_ble_jkbutton_id->set_name("jk-bms retrieve settings");
  jk_bms_ble_jkbutton_id->set_object_id("jk-bms_retrieve_settings");
  jk_bms_ble_jkbutton_id->set_disabled_by_default(false);
  jk_bms_ble_jkbutton_id->set_icon("mdi:cog");
  jk_bms_ble_jkbutton_id->set_parent(bms0);
  jk_bms_ble_jkbutton_id->set_holding_register(150);
  jk_bms_ble_jkbutton_id_2 = new jk_bms_ble::JkButton();
  jk_bms_ble_jkbutton_id_2->set_component_source("jk_bms_ble.button");
  App.register_component(jk_bms_ble_jkbutton_id_2);
  App.register_button(jk_bms_ble_jkbutton_id_2);
  jk_bms_ble_jkbutton_id_2->set_name("jk-bms retrieve device info");
  jk_bms_ble_jkbutton_id_2->set_object_id("jk-bms_retrieve_device_info");
  jk_bms_ble_jkbutton_id_2->set_disabled_by_default(false);
  jk_bms_ble_jkbutton_id_2->set_icon("mdi:information-variant");
  jk_bms_ble_jkbutton_id_2->set_parent(bms0);
  jk_bms_ble_jkbutton_id_2->set_holding_register(151);
  // number.jk_bms_ble:
  //   platform: jk_bms_ble
  //   jk_bms_ble_id: bms0
  //   balance_trigger_voltage:
  //     name: jk-bms balance trigger voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 1.0
  //     step: 0.001
  //   cell_count:
  //     name: jk-bms cell count
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_2
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 24.0
  //     step: 1.0
  //     unit_of_measurement: ''
  //   total_battery_capacity:
  //     name: jk-bms total battery capacity
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_3
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 5.0
  //     max_value: 2000.0
  //     step: 1.0
  //     unit_of_measurement: Ah
  //   cell_voltage_overvoltage_protection:
  //     name: jk-bms cell voltage overvoltage protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_4
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.35
  //     step: 0.001
  //   cell_voltage_overvoltage_recovery:
  //     name: jk-bms cell voltage overvoltage recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_5
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.35
  //     step: 0.001
  //   cell_voltage_undervoltage_protection:
  //     name: jk-bms cell voltage undervoltage protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_6
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.35
  //     step: 0.001
  //   cell_voltage_undervoltage_recovery:
  //     name: jk-bms cell voltage undervoltage recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_7
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.35
  //     step: 0.001
  //   balance_starting_voltage:
  //     name: jk-bms balance starting voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_8
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.25
  //     step: 0.01
  //   voltage_calibration:
  //     name: jk-bms voltage calibration
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_9
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.0
  //     max_value: 200.0
  //     step: 0.01
  //   current_calibration:
  //     name: jk-bms current calibration
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_10
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.0
  //     max_value: 1000.0
  //     step: 0.001
  //     unit_of_measurement: A
  //   power_off_voltage:
  //     name: jk-bms power off voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_11
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.2
  //     max_value: 4.35
  //     step: 0.01
  //   max_balance_current:
  //     name: jk-bms max balance current
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_12
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.3
  //     max_value: 10.0
  //     step: 0.1
  //     unit_of_measurement: A
  //   max_charge_current:
  //     name: jk-bms max charge current
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_13
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.0
  //     max_value: 600.1
  //     step: 0.1
  //     unit_of_measurement: A
  //   max_discharge_current:
  //     name: jk-bms max discharge current
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_14
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 1.0
  //     max_value: 600.1
  //     step: 0.1
  //     unit_of_measurement: A
  //   smart_sleep_voltage:
  //     name: jk-bms smart sleep voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_15
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 3.65
  //     step: 0.001
  //   cell_soc100_voltage:
  //     name: jk-bms cell soc100 voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_16
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 3.65
  //     step: 0.001
  //   cell_soc0_voltage:
  //     name: jk-bms cell soc0 voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_17
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 3.65
  //     step: 0.001
  //   cell_request_charge_voltage:
  //     name: jk-bms cell request charge voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_18
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 3.65
  //     step: 0.001
  //   cell_request_float_voltage:
  //     name: jk-bms cell request float voltage
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_19
  //     icon: ''
  //     unit_of_measurement: V
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.003
  //     max_value: 3.65
  //     step: 0.001
  //   cell_request_charge_voltage_time:
  //     name: jk-bms cell request charge voltage time
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_20
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.0
  //     max_value: 25.5
  //     step: 0.1
  //     unit_of_measurement: h
  //   cell_request_float_voltage_time:
  //     name: jk-bms cell request float voltage time
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_21
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.0
  //     max_value: 25.5
  //     step: 0.1
  //     unit_of_measurement: h
  //   charge_overcurrent_protection_delay:
  //     name: jk-bms charge overcurrent protection delay
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_22
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 600.0
  //     step: 1.0
  //     unit_of_measurement: s
  //   charge_overcurrent_protection_recovery_time:
  //     name: jk-bms charge overcurrent protection recovery time
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_23
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 600.0
  //     step: 1.0
  //     unit_of_measurement: s
  //   discharge_overcurrent_protection_delay:
  //     name: jk-bms discharge overcurrent protection delay
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_24
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 600.0
  //     step: 1.0
  //     unit_of_measurement: s
  //   discharge_overcurrent_protection_recovery_time:
  //     name: jk-bms discharge overcurrent protection recovery time
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_25
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 600.0
  //     step: 1.0
  //     unit_of_measurement: s
  //   short_circuit_protection_delay:
  //     name: jk-bms short circuit protection delay
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_26
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 0.0
  //     max_value: 10000000.0
  //     step: 1.0
  //     unit_of_measurement: μs
  //   short_circuit_protection_recovery_time:
  //     name: jk-bms short circuit protection recovery time
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_27
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 2.0
  //     max_value: 600.0
  //     step: 1.0
  //     unit_of_measurement: s
  //   charge_overtemperature_protection:
  //     name: jk-bms charge overtemperature protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_28
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 80.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   charge_overtemperature_protection_recovery:
  //     name: jk-bms charge overtemperature protection recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_29
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 80.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   discharge_overtemperature_protection:
  //     name: jk-bms discharge overtemperature protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_30
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 80.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   discharge_overtemperature_protection_recovery:
  //     name: jk-bms discharge overtemperature protection recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_31
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 80.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   charge_undertemperature_protection:
  //     name: jk-bms charge undertemperature protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_32
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: -30.0
  //     max_value: 20.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   charge_undertemperature_protection_recovery:
  //     name: jk-bms charge undertemperature protection recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_33
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: -30.0
  //     max_value: 20.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   power_tube_overtemperature_protection:
  //     name: jk-bms power tube overtemperature protection
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_34
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 100.0
  //     step: 0.1
  //     unit_of_measurement: °C
  //   power_tube_overtemperature_protection_recovery:
  //     name: jk-bms power tube overtemperature protection recovery
  //     disabled_by_default: false
  //     id: jk_bms_ble_jknumber_id_35
  //     icon: ''
  //     mode: BOX
  //     entity_category: config
  //     min_value: 30.0
  //     max_value: 100.0
  //     step: 0.1
  //     unit_of_measurement: °C
  jk_bms_ble_jknumber_id_15 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_15->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_15);
  App.register_number(jk_bms_ble_jknumber_id_15);
  jk_bms_ble_jknumber_id_15->set_name("jk-bms smart sleep voltage");
  jk_bms_ble_jknumber_id_15->set_object_id("jk-bms_smart_sleep_voltage");
  jk_bms_ble_jknumber_id_15->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_15->set_icon("");
  jk_bms_ble_jknumber_id_15->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_15->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id_15->traits.set_max_value(3.65f);
  jk_bms_ble_jknumber_id_15->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_15->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_15->traits.set_unit_of_measurement("V");
  bms0->set_smart_sleep_voltage_number(jk_bms_ble_jknumber_id_15);
  jk_bms_ble_jknumber_id_15->set_parent(bms0);
  jk_bms_ble_jknumber_id_15->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_15->set_jk02_holding_register(1);
  jk_bms_ble_jknumber_id_15->set_jk02_32s_holding_register(1);
  jk_bms_ble_jknumber_id_15->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_15->set_length(1);
  jk_bms_ble_jknumber_id_6 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_6->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_6);
  App.register_number(jk_bms_ble_jknumber_id_6);
  jk_bms_ble_jknumber_id_6->set_name("jk-bms cell voltage undervoltage protection");
  jk_bms_ble_jknumber_id_6->set_object_id("jk-bms_cell_voltage_undervoltage_protection");
  jk_bms_ble_jknumber_id_6->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_6->set_icon("");
  jk_bms_ble_jknumber_id_6->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_6->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_6->traits.set_max_value(4.35f);
  jk_bms_ble_jknumber_id_6->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_6->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_6->traits.set_unit_of_measurement("V");
  bms0->set_cell_voltage_undervoltage_protection_number(jk_bms_ble_jknumber_id_6);
  jk_bms_ble_jknumber_id_6->set_parent(bms0);
  jk_bms_ble_jknumber_id_6->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_6->set_jk02_holding_register(2);
  jk_bms_ble_jknumber_id_6->set_jk02_32s_holding_register(2);
  jk_bms_ble_jknumber_id_6->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_6->set_length(4);
  jk_bms_ble_jknumber_id_7 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_7->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_7);
  App.register_number(jk_bms_ble_jknumber_id_7);
  jk_bms_ble_jknumber_id_7->set_name("jk-bms cell voltage undervoltage recovery");
  jk_bms_ble_jknumber_id_7->set_object_id("jk-bms_cell_voltage_undervoltage_recovery");
  jk_bms_ble_jknumber_id_7->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_7->set_icon("");
  jk_bms_ble_jknumber_id_7->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_7->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_7->traits.set_max_value(4.35f);
  jk_bms_ble_jknumber_id_7->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_7->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_7->traits.set_unit_of_measurement("V");
  bms0->set_cell_voltage_undervoltage_recovery_number(jk_bms_ble_jknumber_id_7);
  jk_bms_ble_jknumber_id_7->set_parent(bms0);
  jk_bms_ble_jknumber_id_7->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_7->set_jk02_holding_register(3);
  jk_bms_ble_jknumber_id_7->set_jk02_32s_holding_register(3);
  jk_bms_ble_jknumber_id_7->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_7->set_length(4);
  jk_bms_ble_jknumber_id_4 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_4->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_4);
  App.register_number(jk_bms_ble_jknumber_id_4);
  jk_bms_ble_jknumber_id_4->set_name("jk-bms cell voltage overvoltage protection");
  jk_bms_ble_jknumber_id_4->set_object_id("jk-bms_cell_voltage_overvoltage_protection");
  jk_bms_ble_jknumber_id_4->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_4->set_icon("");
  jk_bms_ble_jknumber_id_4->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_4->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_4->traits.set_max_value(4.35f);
  jk_bms_ble_jknumber_id_4->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_4->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_4->traits.set_unit_of_measurement("V");
  bms0->set_cell_voltage_overvoltage_protection_number(jk_bms_ble_jknumber_id_4);
  jk_bms_ble_jknumber_id_4->set_parent(bms0);
  jk_bms_ble_jknumber_id_4->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_4->set_jk02_holding_register(4);
  jk_bms_ble_jknumber_id_4->set_jk02_32s_holding_register(4);
  jk_bms_ble_jknumber_id_4->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_4->set_length(4);
  jk_bms_ble_jknumber_id_5 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_5->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_5);
  App.register_number(jk_bms_ble_jknumber_id_5);
  jk_bms_ble_jknumber_id_5->set_name("jk-bms cell voltage overvoltage recovery");
  jk_bms_ble_jknumber_id_5->set_object_id("jk-bms_cell_voltage_overvoltage_recovery");
  jk_bms_ble_jknumber_id_5->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_5->set_icon("");
  jk_bms_ble_jknumber_id_5->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_5->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_5->traits.set_max_value(4.35f);
  jk_bms_ble_jknumber_id_5->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_5->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_5->traits.set_unit_of_measurement("V");
  bms0->set_cell_voltage_overvoltage_recovery_number(jk_bms_ble_jknumber_id_5);
  jk_bms_ble_jknumber_id_5->set_parent(bms0);
  jk_bms_ble_jknumber_id_5->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_5->set_jk02_holding_register(5);
  jk_bms_ble_jknumber_id_5->set_jk02_32s_holding_register(5);
  jk_bms_ble_jknumber_id_5->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_5->set_length(4);
  jk_bms_ble_jknumber_id = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id);
  App.register_number(jk_bms_ble_jknumber_id);
  jk_bms_ble_jknumber_id->set_name("jk-bms balance trigger voltage");
  jk_bms_ble_jknumber_id->set_object_id("jk-bms_balance_trigger_voltage");
  jk_bms_ble_jknumber_id->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id->set_icon("");
  jk_bms_ble_jknumber_id->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id->traits.set_max_value(1.0f);
  jk_bms_ble_jknumber_id->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id->traits.set_unit_of_measurement("V");
  bms0->set_balance_trigger_voltage_number(jk_bms_ble_jknumber_id);
  jk_bms_ble_jknumber_id->set_parent(bms0);
  jk_bms_ble_jknumber_id->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id->set_jk02_holding_register(6);
  jk_bms_ble_jknumber_id->set_jk02_32s_holding_register(6);
  jk_bms_ble_jknumber_id->set_factor(1000.0f);
  jk_bms_ble_jknumber_id->set_length(4);
  jk_bms_ble_jknumber_id_16 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_16->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_16);
  App.register_number(jk_bms_ble_jknumber_id_16);
  jk_bms_ble_jknumber_id_16->set_name("jk-bms cell soc100 voltage");
  jk_bms_ble_jknumber_id_16->set_object_id("jk-bms_cell_soc100_voltage");
  jk_bms_ble_jknumber_id_16->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_16->set_icon("");
  jk_bms_ble_jknumber_id_16->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_16->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id_16->traits.set_max_value(3.65f);
  jk_bms_ble_jknumber_id_16->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_16->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_16->traits.set_unit_of_measurement("V");
  bms0->set_cell_soc100_voltage_number(jk_bms_ble_jknumber_id_16);
  jk_bms_ble_jknumber_id_16->set_parent(bms0);
  jk_bms_ble_jknumber_id_16->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_16->set_jk02_holding_register(7);
  jk_bms_ble_jknumber_id_16->set_jk02_32s_holding_register(7);
  jk_bms_ble_jknumber_id_16->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_16->set_length(4);
  jk_bms_ble_jknumber_id_17 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_17->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_17);
  App.register_number(jk_bms_ble_jknumber_id_17);
  jk_bms_ble_jknumber_id_17->set_name("jk-bms cell soc0 voltage");
  jk_bms_ble_jknumber_id_17->set_object_id("jk-bms_cell_soc0_voltage");
  jk_bms_ble_jknumber_id_17->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_17->set_icon("");
  jk_bms_ble_jknumber_id_17->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_17->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id_17->traits.set_max_value(3.65f);
  jk_bms_ble_jknumber_id_17->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_17->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_17->traits.set_unit_of_measurement("V");
  bms0->set_cell_soc0_voltage_number(jk_bms_ble_jknumber_id_17);
  jk_bms_ble_jknumber_id_17->set_parent(bms0);
  jk_bms_ble_jknumber_id_17->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_17->set_jk02_holding_register(8);
  jk_bms_ble_jknumber_id_17->set_jk02_32s_holding_register(8);
  jk_bms_ble_jknumber_id_17->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_17->set_length(4);
  jk_bms_ble_jknumber_id_18 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_18->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_18);
  App.register_number(jk_bms_ble_jknumber_id_18);
  jk_bms_ble_jknumber_id_18->set_name("jk-bms cell request charge voltage");
  jk_bms_ble_jknumber_id_18->set_object_id("jk-bms_cell_request_charge_voltage");
  jk_bms_ble_jknumber_id_18->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_18->set_icon("");
  jk_bms_ble_jknumber_id_18->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_18->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id_18->traits.set_max_value(3.65f);
  jk_bms_ble_jknumber_id_18->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_18->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_18->traits.set_unit_of_measurement("V");
  bms0->set_cell_request_charge_voltage_number(jk_bms_ble_jknumber_id_18);
  jk_bms_ble_jknumber_id_18->set_parent(bms0);
  jk_bms_ble_jknumber_id_18->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_18->set_jk02_holding_register(9);
  jk_bms_ble_jknumber_id_18->set_jk02_32s_holding_register(9);
  jk_bms_ble_jknumber_id_18->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_18->set_length(4);
  jk_bms_ble_jknumber_id_19 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_19->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_19);
  App.register_number(jk_bms_ble_jknumber_id_19);
  jk_bms_ble_jknumber_id_19->set_name("jk-bms cell request float voltage");
  jk_bms_ble_jknumber_id_19->set_object_id("jk-bms_cell_request_float_voltage");
  jk_bms_ble_jknumber_id_19->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_19->set_icon("");
  jk_bms_ble_jknumber_id_19->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_19->traits.set_min_value(0.003f);
  jk_bms_ble_jknumber_id_19->traits.set_max_value(3.65f);
  jk_bms_ble_jknumber_id_19->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_19->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_19->traits.set_unit_of_measurement("V");
  bms0->set_cell_request_float_voltage_number(jk_bms_ble_jknumber_id_19);
  jk_bms_ble_jknumber_id_19->set_parent(bms0);
  jk_bms_ble_jknumber_id_19->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_19->set_jk02_holding_register(10);
  jk_bms_ble_jknumber_id_19->set_jk02_32s_holding_register(10);
  jk_bms_ble_jknumber_id_19->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_19->set_length(4);
  jk_bms_ble_jknumber_id_20 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_20->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_20);
  App.register_number(jk_bms_ble_jknumber_id_20);
  jk_bms_ble_jknumber_id_20->set_name("jk-bms cell request charge voltage time");
  jk_bms_ble_jknumber_id_20->set_object_id("jk-bms_cell_request_charge_voltage_time");
  jk_bms_ble_jknumber_id_20->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_20->set_icon("");
  jk_bms_ble_jknumber_id_20->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_20->traits.set_min_value(0.0f);
  jk_bms_ble_jknumber_id_20->traits.set_max_value(25.5f);
  jk_bms_ble_jknumber_id_20->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_20->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_20->traits.set_unit_of_measurement("h");
  bms0->set_cell_request_charge_voltage_time_number(jk_bms_ble_jknumber_id_20);
  jk_bms_ble_jknumber_id_20->set_parent(bms0);
  jk_bms_ble_jknumber_id_20->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_20->set_jk02_holding_register(0);
  jk_bms_ble_jknumber_id_20->set_jk02_32s_holding_register(179);
  jk_bms_ble_jknumber_id_20->set_factor(10.0f);
  jk_bms_ble_jknumber_id_20->set_length(1);
  jk_bms_ble_jknumber_id_21 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_21->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_21);
  App.register_number(jk_bms_ble_jknumber_id_21);
  jk_bms_ble_jknumber_id_21->set_name("jk-bms cell request float voltage time");
  jk_bms_ble_jknumber_id_21->set_object_id("jk-bms_cell_request_float_voltage_time");
  jk_bms_ble_jknumber_id_21->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_21->set_icon("");
  jk_bms_ble_jknumber_id_21->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_21->traits.set_min_value(0.0f);
  jk_bms_ble_jknumber_id_21->traits.set_max_value(25.5f);
  jk_bms_ble_jknumber_id_21->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_21->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_21->traits.set_unit_of_measurement("h");
  bms0->set_cell_request_float_voltage_time_number(jk_bms_ble_jknumber_id_21);
  jk_bms_ble_jknumber_id_21->set_parent(bms0);
  jk_bms_ble_jknumber_id_21->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_21->set_jk02_holding_register(0);
  jk_bms_ble_jknumber_id_21->set_jk02_32s_holding_register(180);
  jk_bms_ble_jknumber_id_21->set_factor(10.0f);
  jk_bms_ble_jknumber_id_21->set_length(1);
  jk_bms_ble_jknumber_id_2 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_2->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_2);
  App.register_number(jk_bms_ble_jknumber_id_2);
  jk_bms_ble_jknumber_id_2->set_name("jk-bms cell count");
  jk_bms_ble_jknumber_id_2->set_object_id("jk-bms_cell_count");
  jk_bms_ble_jknumber_id_2->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_2->set_icon("");
  jk_bms_ble_jknumber_id_2->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_2->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_2->traits.set_max_value(24.0f);
  jk_bms_ble_jknumber_id_2->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_2->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_2->traits.set_unit_of_measurement("");
  bms0->set_cell_count_number(jk_bms_ble_jknumber_id_2);
  jk_bms_ble_jknumber_id_2->set_parent(bms0);
  jk_bms_ble_jknumber_id_2->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_2->set_jk02_holding_register(28);
  jk_bms_ble_jknumber_id_2->set_jk02_32s_holding_register(28);
  jk_bms_ble_jknumber_id_2->set_factor(1.0f);
  jk_bms_ble_jknumber_id_2->set_length(4);
  jk_bms_ble_jknumber_id_3 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_3->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_3);
  App.register_number(jk_bms_ble_jknumber_id_3);
  jk_bms_ble_jknumber_id_3->set_name("jk-bms total battery capacity");
  jk_bms_ble_jknumber_id_3->set_object_id("jk-bms_total_battery_capacity");
  jk_bms_ble_jknumber_id_3->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_3->set_icon("");
  jk_bms_ble_jknumber_id_3->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_3->traits.set_min_value(5.0f);
  jk_bms_ble_jknumber_id_3->traits.set_max_value(2000.0f);
  jk_bms_ble_jknumber_id_3->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_3->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_3->traits.set_unit_of_measurement("Ah");
  bms0->set_total_battery_capacity_number(jk_bms_ble_jknumber_id_3);
  jk_bms_ble_jknumber_id_3->set_parent(bms0);
  jk_bms_ble_jknumber_id_3->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_3->set_jk02_holding_register(32);
  jk_bms_ble_jknumber_id_3->set_jk02_32s_holding_register(32);
  jk_bms_ble_jknumber_id_3->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_3->set_length(4);
  jk_bms_ble_jknumber_id_8 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_8->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_8);
  App.register_number(jk_bms_ble_jknumber_id_8);
  jk_bms_ble_jknumber_id_8->set_name("jk-bms balance starting voltage");
  jk_bms_ble_jknumber_id_8->set_object_id("jk-bms_balance_starting_voltage");
  jk_bms_ble_jknumber_id_8->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_8->set_icon("");
  jk_bms_ble_jknumber_id_8->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_8->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_8->traits.set_max_value(4.25f);
  jk_bms_ble_jknumber_id_8->traits.set_step(0.01f);
  jk_bms_ble_jknumber_id_8->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_8->traits.set_unit_of_measurement("V");
  bms0->set_balance_starting_voltage_number(jk_bms_ble_jknumber_id_8);
  jk_bms_ble_jknumber_id_8->set_parent(bms0);
  jk_bms_ble_jknumber_id_8->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_8->set_jk02_holding_register(38);
  jk_bms_ble_jknumber_id_8->set_jk02_32s_holding_register(34);
  jk_bms_ble_jknumber_id_8->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_8->set_length(4);
  jk_bms_ble_jknumber_id_9 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_9->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_9);
  App.register_number(jk_bms_ble_jknumber_id_9);
  jk_bms_ble_jknumber_id_9->set_name("jk-bms voltage calibration");
  jk_bms_ble_jknumber_id_9->set_object_id("jk-bms_voltage_calibration");
  jk_bms_ble_jknumber_id_9->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_9->set_icon("");
  jk_bms_ble_jknumber_id_9->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_9->traits.set_min_value(1.0f);
  jk_bms_ble_jknumber_id_9->traits.set_max_value(200.0f);
  jk_bms_ble_jknumber_id_9->traits.set_step(0.01f);
  jk_bms_ble_jknumber_id_9->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_9->traits.set_unit_of_measurement("V");
  bms0->set_voltage_calibration_number(jk_bms_ble_jknumber_id_9);
  jk_bms_ble_jknumber_id_9->set_parent(bms0);
  jk_bms_ble_jknumber_id_9->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_9->set_jk02_holding_register(33);
  jk_bms_ble_jknumber_id_9->set_jk02_32s_holding_register(100);
  jk_bms_ble_jknumber_id_9->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_9->set_length(4);
  jk_bms_ble_jknumber_id_10 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_10->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_10);
  App.register_number(jk_bms_ble_jknumber_id_10);
  jk_bms_ble_jknumber_id_10->set_name("jk-bms current calibration");
  jk_bms_ble_jknumber_id_10->set_object_id("jk-bms_current_calibration");
  jk_bms_ble_jknumber_id_10->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_10->set_icon("");
  jk_bms_ble_jknumber_id_10->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_10->traits.set_min_value(0.0f);
  jk_bms_ble_jknumber_id_10->traits.set_max_value(1000.0f);
  jk_bms_ble_jknumber_id_10->traits.set_step(0.001f);
  jk_bms_ble_jknumber_id_10->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_10->traits.set_unit_of_measurement("A");
  bms0->set_current_calibration_number(jk_bms_ble_jknumber_id_10);
  jk_bms_ble_jknumber_id_10->set_parent(bms0);
  jk_bms_ble_jknumber_id_10->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_10->set_jk02_holding_register(36);
  jk_bms_ble_jknumber_id_10->set_jk02_32s_holding_register(103);
  jk_bms_ble_jknumber_id_10->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_10->set_length(4);
  jk_bms_ble_jknumber_id_11 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_11->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_11);
  App.register_number(jk_bms_ble_jknumber_id_11);
  jk_bms_ble_jknumber_id_11->set_name("jk-bms power off voltage");
  jk_bms_ble_jknumber_id_11->set_object_id("jk-bms_power_off_voltage");
  jk_bms_ble_jknumber_id_11->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_11->set_icon("");
  jk_bms_ble_jknumber_id_11->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_11->traits.set_min_value(1.2f);
  jk_bms_ble_jknumber_id_11->traits.set_max_value(4.35f);
  jk_bms_ble_jknumber_id_11->traits.set_step(0.01f);
  jk_bms_ble_jknumber_id_11->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_11->traits.set_unit_of_measurement("V");
  bms0->set_power_off_voltage_number(jk_bms_ble_jknumber_id_11);
  jk_bms_ble_jknumber_id_11->set_parent(bms0);
  jk_bms_ble_jknumber_id_11->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_11->set_jk02_holding_register(11);
  jk_bms_ble_jknumber_id_11->set_jk02_32s_holding_register(11);
  jk_bms_ble_jknumber_id_11->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_11->set_length(4);
  jk_bms_ble_jknumber_id_12 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_12->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_12);
  App.register_number(jk_bms_ble_jknumber_id_12);
  jk_bms_ble_jknumber_id_12->set_name("jk-bms max balance current");
  jk_bms_ble_jknumber_id_12->set_object_id("jk-bms_max_balance_current");
  jk_bms_ble_jknumber_id_12->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_12->set_icon("");
  jk_bms_ble_jknumber_id_12->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_12->traits.set_min_value(0.3f);
  jk_bms_ble_jknumber_id_12->traits.set_max_value(10.0f);
  jk_bms_ble_jknumber_id_12->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_12->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_12->traits.set_unit_of_measurement("A");
  bms0->set_max_balance_current_number(jk_bms_ble_jknumber_id_12);
  jk_bms_ble_jknumber_id_12->set_parent(bms0);
  jk_bms_ble_jknumber_id_12->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_12->set_jk02_holding_register(19);
  jk_bms_ble_jknumber_id_12->set_jk02_32s_holding_register(19);
  jk_bms_ble_jknumber_id_12->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_12->set_length(4);
  jk_bms_ble_jknumber_id_13 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_13->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_13);
  App.register_number(jk_bms_ble_jknumber_id_13);
  jk_bms_ble_jknumber_id_13->set_name("jk-bms max charge current");
  jk_bms_ble_jknumber_id_13->set_object_id("jk-bms_max_charge_current");
  jk_bms_ble_jknumber_id_13->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_13->set_icon("");
  jk_bms_ble_jknumber_id_13->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_13->traits.set_min_value(1.0f);
  jk_bms_ble_jknumber_id_13->traits.set_max_value(600.1f);
  jk_bms_ble_jknumber_id_13->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_13->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_13->traits.set_unit_of_measurement("A");
  bms0->set_max_charge_current_number(jk_bms_ble_jknumber_id_13);
  jk_bms_ble_jknumber_id_13->set_parent(bms0);
  jk_bms_ble_jknumber_id_13->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_13->set_jk02_holding_register(12);
  jk_bms_ble_jknumber_id_13->set_jk02_32s_holding_register(12);
  jk_bms_ble_jknumber_id_13->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_13->set_length(4);
  jk_bms_ble_jknumber_id_14 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_14->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_14);
  App.register_number(jk_bms_ble_jknumber_id_14);
  jk_bms_ble_jknumber_id_14->set_name("jk-bms max discharge current");
  jk_bms_ble_jknumber_id_14->set_object_id("jk-bms_max_discharge_current");
  jk_bms_ble_jknumber_id_14->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_14->set_icon("");
  jk_bms_ble_jknumber_id_14->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_14->traits.set_min_value(1.0f);
  jk_bms_ble_jknumber_id_14->traits.set_max_value(600.1f);
  jk_bms_ble_jknumber_id_14->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_14->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_14->traits.set_unit_of_measurement("A");
  bms0->set_max_discharge_current_number(jk_bms_ble_jknumber_id_14);
  jk_bms_ble_jknumber_id_14->set_parent(bms0);
  jk_bms_ble_jknumber_id_14->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_14->set_jk02_holding_register(15);
  jk_bms_ble_jknumber_id_14->set_jk02_32s_holding_register(15);
  jk_bms_ble_jknumber_id_14->set_factor(1000.0f);
  jk_bms_ble_jknumber_id_14->set_length(4);
  jk_bms_ble_jknumber_id_22 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_22->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_22);
  App.register_number(jk_bms_ble_jknumber_id_22);
  jk_bms_ble_jknumber_id_22->set_name("jk-bms charge overcurrent protection delay");
  jk_bms_ble_jknumber_id_22->set_object_id("jk-bms_charge_overcurrent_protection_delay");
  jk_bms_ble_jknumber_id_22->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_22->set_icon("");
  jk_bms_ble_jknumber_id_22->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_22->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_22->traits.set_max_value(600.0f);
  jk_bms_ble_jknumber_id_22->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_22->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_22->traits.set_unit_of_measurement("s");
  bms0->set_charge_overcurrent_protection_delay_number(jk_bms_ble_jknumber_id_22);
  jk_bms_ble_jknumber_id_22->set_parent(bms0);
  jk_bms_ble_jknumber_id_22->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_22->set_jk02_holding_register(13);
  jk_bms_ble_jknumber_id_22->set_jk02_32s_holding_register(13);
  jk_bms_ble_jknumber_id_22->set_factor(1.0f);
  jk_bms_ble_jknumber_id_22->set_length(4);
  jk_bms_ble_jknumber_id_23 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_23->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_23);
  App.register_number(jk_bms_ble_jknumber_id_23);
  jk_bms_ble_jknumber_id_23->set_name("jk-bms charge overcurrent protection recovery time");
  jk_bms_ble_jknumber_id_23->set_object_id("jk-bms_charge_overcurrent_protection_recovery_time");
  jk_bms_ble_jknumber_id_23->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_23->set_icon("");
  jk_bms_ble_jknumber_id_23->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_23->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_23->traits.set_max_value(600.0f);
  jk_bms_ble_jknumber_id_23->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_23->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_23->traits.set_unit_of_measurement("s");
  bms0->set_charge_overcurrent_protection_recovery_time_number(jk_bms_ble_jknumber_id_23);
  jk_bms_ble_jknumber_id_23->set_parent(bms0);
  jk_bms_ble_jknumber_id_23->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_23->set_jk02_holding_register(14);
  jk_bms_ble_jknumber_id_23->set_jk02_32s_holding_register(14);
  jk_bms_ble_jknumber_id_23->set_factor(1.0f);
  jk_bms_ble_jknumber_id_23->set_length(4);
  jk_bms_ble_jknumber_id_24 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_24->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_24);
  App.register_number(jk_bms_ble_jknumber_id_24);
  jk_bms_ble_jknumber_id_24->set_name("jk-bms discharge overcurrent protection delay");
  jk_bms_ble_jknumber_id_24->set_object_id("jk-bms_discharge_overcurrent_protection_delay");
  jk_bms_ble_jknumber_id_24->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_24->set_icon("");
  jk_bms_ble_jknumber_id_24->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_24->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_24->traits.set_max_value(600.0f);
  jk_bms_ble_jknumber_id_24->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_24->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_24->traits.set_unit_of_measurement("s");
  bms0->set_discharge_overcurrent_protection_delay_number(jk_bms_ble_jknumber_id_24);
  jk_bms_ble_jknumber_id_24->set_parent(bms0);
  jk_bms_ble_jknumber_id_24->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_24->set_jk02_holding_register(16);
  jk_bms_ble_jknumber_id_24->set_jk02_32s_holding_register(16);
  jk_bms_ble_jknumber_id_24->set_factor(1.0f);
  jk_bms_ble_jknumber_id_24->set_length(4);
  jk_bms_ble_jknumber_id_25 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_25->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_25);
  App.register_number(jk_bms_ble_jknumber_id_25);
  jk_bms_ble_jknumber_id_25->set_name("jk-bms discharge overcurrent protection recovery time");
  jk_bms_ble_jknumber_id_25->set_object_id("jk-bms_discharge_overcurrent_protection_recovery_time");
  jk_bms_ble_jknumber_id_25->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_25->set_icon("");
  jk_bms_ble_jknumber_id_25->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_25->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_25->traits.set_max_value(600.0f);
  jk_bms_ble_jknumber_id_25->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_25->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_25->traits.set_unit_of_measurement("s");
  bms0->set_discharge_overcurrent_protection_recovery_time_number(jk_bms_ble_jknumber_id_25);
  jk_bms_ble_jknumber_id_25->set_parent(bms0);
  jk_bms_ble_jknumber_id_25->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_25->set_jk02_holding_register(17);
  jk_bms_ble_jknumber_id_25->set_jk02_32s_holding_register(17);
  jk_bms_ble_jknumber_id_25->set_factor(1.0f);
  jk_bms_ble_jknumber_id_25->set_length(4);
  jk_bms_ble_jknumber_id_26 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_26->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_26);
  App.register_number(jk_bms_ble_jknumber_id_26);
  jk_bms_ble_jknumber_id_26->set_name("jk-bms short circuit protection delay");
  jk_bms_ble_jknumber_id_26->set_object_id("jk-bms_short_circuit_protection_delay");
  jk_bms_ble_jknumber_id_26->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_26->set_icon("");
  jk_bms_ble_jknumber_id_26->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_26->traits.set_min_value(0.0f);
  jk_bms_ble_jknumber_id_26->traits.set_max_value(10000000.0f);
  jk_bms_ble_jknumber_id_26->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_26->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_26->traits.set_unit_of_measurement("\316\274s");
  bms0->set_short_circuit_protection_delay_number(jk_bms_ble_jknumber_id_26);
  jk_bms_ble_jknumber_id_26->set_parent(bms0);
  jk_bms_ble_jknumber_id_26->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_26->set_jk02_holding_register(37);
  jk_bms_ble_jknumber_id_26->set_jk02_32s_holding_register(33);
  jk_bms_ble_jknumber_id_26->set_factor(1.0f);
  jk_bms_ble_jknumber_id_26->set_length(4);
  jk_bms_ble_jknumber_id_27 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_27->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_27);
  App.register_number(jk_bms_ble_jknumber_id_27);
  jk_bms_ble_jknumber_id_27->set_name("jk-bms short circuit protection recovery time");
  jk_bms_ble_jknumber_id_27->set_object_id("jk-bms_short_circuit_protection_recovery_time");
  jk_bms_ble_jknumber_id_27->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_27->set_icon("");
  jk_bms_ble_jknumber_id_27->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_27->traits.set_min_value(2.0f);
  jk_bms_ble_jknumber_id_27->traits.set_max_value(600.0f);
  jk_bms_ble_jknumber_id_27->traits.set_step(1.0f);
  jk_bms_ble_jknumber_id_27->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_27->traits.set_unit_of_measurement("s");
  bms0->set_short_circuit_protection_recovery_time_number(jk_bms_ble_jknumber_id_27);
  jk_bms_ble_jknumber_id_27->set_parent(bms0);
  jk_bms_ble_jknumber_id_27->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_27->set_jk02_holding_register(18);
  jk_bms_ble_jknumber_id_27->set_jk02_32s_holding_register(18);
  jk_bms_ble_jknumber_id_27->set_factor(1.0f);
  jk_bms_ble_jknumber_id_27->set_length(4);
  jk_bms_ble_jknumber_id_28 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_28->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_28);
  App.register_number(jk_bms_ble_jknumber_id_28);
  jk_bms_ble_jknumber_id_28->set_name("jk-bms charge overtemperature protection");
  jk_bms_ble_jknumber_id_28->set_object_id("jk-bms_charge_overtemperature_protection");
  jk_bms_ble_jknumber_id_28->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_28->set_icon("");
  jk_bms_ble_jknumber_id_28->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_28->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_28->traits.set_max_value(80.0f);
  jk_bms_ble_jknumber_id_28->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_28->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_28->traits.set_unit_of_measurement("\302\260C");
  bms0->set_charge_overtemperature_protection_number(jk_bms_ble_jknumber_id_28);
  jk_bms_ble_jknumber_id_28->set_parent(bms0);
  jk_bms_ble_jknumber_id_28->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_28->set_jk02_holding_register(20);
  jk_bms_ble_jknumber_id_28->set_jk02_32s_holding_register(20);
  jk_bms_ble_jknumber_id_28->set_factor(10.0f);
  jk_bms_ble_jknumber_id_28->set_length(4);
  jk_bms_ble_jknumber_id_29 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_29->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_29);
  App.register_number(jk_bms_ble_jknumber_id_29);
  jk_bms_ble_jknumber_id_29->set_name("jk-bms charge overtemperature protection recovery");
  jk_bms_ble_jknumber_id_29->set_object_id("jk-bms_charge_overtemperature_protection_recovery");
  jk_bms_ble_jknumber_id_29->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_29->set_icon("");
  jk_bms_ble_jknumber_id_29->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_29->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_29->traits.set_max_value(80.0f);
  jk_bms_ble_jknumber_id_29->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_29->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_29->traits.set_unit_of_measurement("\302\260C");
  bms0->set_charge_overtemperature_protection_recovery_number(jk_bms_ble_jknumber_id_29);
  jk_bms_ble_jknumber_id_29->set_parent(bms0);
  jk_bms_ble_jknumber_id_29->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_29->set_jk02_holding_register(21);
  jk_bms_ble_jknumber_id_29->set_jk02_32s_holding_register(21);
  jk_bms_ble_jknumber_id_29->set_factor(10.0f);
  jk_bms_ble_jknumber_id_29->set_length(4);
  jk_bms_ble_jknumber_id_30 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_30->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_30);
  App.register_number(jk_bms_ble_jknumber_id_30);
  jk_bms_ble_jknumber_id_30->set_name("jk-bms discharge overtemperature protection");
  jk_bms_ble_jknumber_id_30->set_object_id("jk-bms_discharge_overtemperature_protection");
  jk_bms_ble_jknumber_id_30->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_30->set_icon("");
  jk_bms_ble_jknumber_id_30->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_30->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_30->traits.set_max_value(80.0f);
  jk_bms_ble_jknumber_id_30->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_30->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_30->traits.set_unit_of_measurement("\302\260C");
  bms0->set_discharge_overtemperature_protection_number(jk_bms_ble_jknumber_id_30);
  jk_bms_ble_jknumber_id_30->set_parent(bms0);
  jk_bms_ble_jknumber_id_30->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_30->set_jk02_holding_register(22);
  jk_bms_ble_jknumber_id_30->set_jk02_32s_holding_register(22);
  jk_bms_ble_jknumber_id_30->set_factor(10.0f);
  jk_bms_ble_jknumber_id_30->set_length(4);
  jk_bms_ble_jknumber_id_31 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_31->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_31);
  App.register_number(jk_bms_ble_jknumber_id_31);
  jk_bms_ble_jknumber_id_31->set_name("jk-bms discharge overtemperature protection recovery");
  jk_bms_ble_jknumber_id_31->set_object_id("jk-bms_discharge_overtemperature_protection_recovery");
  jk_bms_ble_jknumber_id_31->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_31->set_icon("");
  jk_bms_ble_jknumber_id_31->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_31->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_31->traits.set_max_value(80.0f);
  jk_bms_ble_jknumber_id_31->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_31->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_31->traits.set_unit_of_measurement("\302\260C");
  bms0->set_discharge_overtemperature_protection_recovery_number(jk_bms_ble_jknumber_id_31);
  jk_bms_ble_jknumber_id_31->set_parent(bms0);
  jk_bms_ble_jknumber_id_31->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_31->set_jk02_holding_register(23);
  jk_bms_ble_jknumber_id_31->set_jk02_32s_holding_register(23);
  jk_bms_ble_jknumber_id_31->set_factor(10.0f);
  jk_bms_ble_jknumber_id_31->set_length(4);
  jk_bms_ble_jknumber_id_32 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_32->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_32);
  App.register_number(jk_bms_ble_jknumber_id_32);
  jk_bms_ble_jknumber_id_32->set_name("jk-bms charge undertemperature protection");
  jk_bms_ble_jknumber_id_32->set_object_id("jk-bms_charge_undertemperature_protection");
  jk_bms_ble_jknumber_id_32->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_32->set_icon("");
  jk_bms_ble_jknumber_id_32->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_32->traits.set_min_value(-30.0f);
  jk_bms_ble_jknumber_id_32->traits.set_max_value(20.0f);
  jk_bms_ble_jknumber_id_32->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_32->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_32->traits.set_unit_of_measurement("\302\260C");
  bms0->set_charge_undertemperature_protection_number(jk_bms_ble_jknumber_id_32);
  jk_bms_ble_jknumber_id_32->set_parent(bms0);
  jk_bms_ble_jknumber_id_32->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_32->set_jk02_holding_register(24);
  jk_bms_ble_jknumber_id_32->set_jk02_32s_holding_register(24);
  jk_bms_ble_jknumber_id_32->set_factor(10.0f);
  jk_bms_ble_jknumber_id_32->set_length(4);
  jk_bms_ble_jknumber_id_33 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_33->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_33);
  App.register_number(jk_bms_ble_jknumber_id_33);
  jk_bms_ble_jknumber_id_33->set_name("jk-bms charge undertemperature protection recovery");
  jk_bms_ble_jknumber_id_33->set_object_id("jk-bms_charge_undertemperature_protection_recovery");
  jk_bms_ble_jknumber_id_33->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_33->set_icon("");
  jk_bms_ble_jknumber_id_33->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_33->traits.set_min_value(-30.0f);
  jk_bms_ble_jknumber_id_33->traits.set_max_value(20.0f);
  jk_bms_ble_jknumber_id_33->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_33->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_33->traits.set_unit_of_measurement("\302\260C");
  bms0->set_charge_undertemperature_protection_recovery_number(jk_bms_ble_jknumber_id_33);
  jk_bms_ble_jknumber_id_33->set_parent(bms0);
  jk_bms_ble_jknumber_id_33->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_33->set_jk02_holding_register(25);
  jk_bms_ble_jknumber_id_33->set_jk02_32s_holding_register(25);
  jk_bms_ble_jknumber_id_33->set_factor(10.0f);
  jk_bms_ble_jknumber_id_33->set_length(4);
  jk_bms_ble_jknumber_id_34 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_34->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_34);
  App.register_number(jk_bms_ble_jknumber_id_34);
  jk_bms_ble_jknumber_id_34->set_name("jk-bms power tube overtemperature protection");
  jk_bms_ble_jknumber_id_34->set_object_id("jk-bms_power_tube_overtemperature_protection");
  jk_bms_ble_jknumber_id_34->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_34->set_icon("");
  jk_bms_ble_jknumber_id_34->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_34->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_34->traits.set_max_value(100.0f);
  jk_bms_ble_jknumber_id_34->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_34->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_34->traits.set_unit_of_measurement("\302\260C");
  bms0->set_power_tube_overtemperature_protection_number(jk_bms_ble_jknumber_id_34);
  jk_bms_ble_jknumber_id_34->set_parent(bms0);
  jk_bms_ble_jknumber_id_34->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_34->set_jk02_holding_register(26);
  jk_bms_ble_jknumber_id_34->set_jk02_32s_holding_register(26);
  jk_bms_ble_jknumber_id_34->set_factor(10.0f);
  jk_bms_ble_jknumber_id_34->set_length(4);
  jk_bms_ble_jknumber_id_35 = new jk_bms_ble::JkNumber();
  jk_bms_ble_jknumber_id_35->set_component_source("jk_bms_ble.number");
  App.register_component(jk_bms_ble_jknumber_id_35);
  App.register_number(jk_bms_ble_jknumber_id_35);
  jk_bms_ble_jknumber_id_35->set_name("jk-bms power tube overtemperature protection recovery");
  jk_bms_ble_jknumber_id_35->set_object_id("jk-bms_power_tube_overtemperature_protection_recovery");
  jk_bms_ble_jknumber_id_35->set_disabled_by_default(false);
  jk_bms_ble_jknumber_id_35->set_icon("");
  jk_bms_ble_jknumber_id_35->set_entity_category(::ENTITY_CATEGORY_CONFIG);
  jk_bms_ble_jknumber_id_35->traits.set_min_value(30.0f);
  jk_bms_ble_jknumber_id_35->traits.set_max_value(100.0f);
  jk_bms_ble_jknumber_id_35->traits.set_step(0.1f);
  jk_bms_ble_jknumber_id_35->traits.set_mode(number::NUMBER_MODE_BOX);
  jk_bms_ble_jknumber_id_35->traits.set_unit_of_measurement("\302\260C");
  bms0->set_power_tube_overtemperature_protection_recovery_number(jk_bms_ble_jknumber_id_35);
  jk_bms_ble_jknumber_id_35->set_parent(bms0);
  jk_bms_ble_jknumber_id_35->set_jk04_holding_register(0);
  jk_bms_ble_jknumber_id_35->set_jk02_holding_register(27);
  jk_bms_ble_jknumber_id_35->set_jk02_32s_holding_register(27);
  jk_bms_ble_jknumber_id_35->set_factor(10.0f);
  jk_bms_ble_jknumber_id_35->set_length(4);
  // sensor.jk_bms_ble:
  //   platform: jk_bms_ble
  //   jk_bms_ble_id: bms0
  //   min_cell_voltage:
  //     name: jk-bms min cell voltage
  //     disabled_by_default: false
  //     id: sensor_sensor_id
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   max_cell_voltage:
  //     name: jk-bms max cell voltage
  //     disabled_by_default: false
  //     id: sensor_sensor_id_2
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   min_voltage_cell:
  //     name: jk-bms min voltage cell
  //     disabled_by_default: false
  //     id: sensor_sensor_id_3
  //     force_update: false
  //     unit_of_measurement: ''
  //     icon: mdi:battery-minus-outline
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   max_voltage_cell:
  //     name: jk-bms max voltage cell
  //     disabled_by_default: false
  //     id: sensor_sensor_id_4
  //     force_update: false
  //     unit_of_measurement: ''
  //     icon: mdi:battery-plus-outline
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   delta_cell_voltage:
  //     name: jk-bms delta cell voltage
  //     disabled_by_default: false
  //     id: sensor_sensor_id_5
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   average_cell_voltage:
  //     name: jk-bms average cell voltage
  //     disabled_by_default: false
  //     id: sensor_sensor_id_6
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_1:
  //     name: jk-bms cell voltage 1
  //     disabled_by_default: false
  //     id: sensor_sensor_id_7
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_2:
  //     name: jk-bms cell voltage 2
  //     disabled_by_default: false
  //     id: sensor_sensor_id_8
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_3:
  //     name: jk-bms cell voltage 3
  //     disabled_by_default: false
  //     id: sensor_sensor_id_9
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_4:
  //     name: jk-bms cell voltage 4
  //     disabled_by_default: false
  //     id: sensor_sensor_id_10
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_5:
  //     name: jk-bms cell voltage 5
  //     disabled_by_default: false
  //     id: sensor_sensor_id_11
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_6:
  //     name: jk-bms cell voltage 6
  //     disabled_by_default: false
  //     id: sensor_sensor_id_12
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_7:
  //     name: jk-bms cell voltage 7
  //     disabled_by_default: false
  //     id: sensor_sensor_id_13
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_8:
  //     name: jk-bms cell voltage 8
  //     disabled_by_default: false
  //     id: sensor_sensor_id_14
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_9:
  //     name: jk-bms cell voltage 9
  //     disabled_by_default: false
  //     id: sensor_sensor_id_15
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_10:
  //     name: jk-bms cell voltage 10
  //     disabled_by_default: false
  //     id: sensor_sensor_id_16
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_11:
  //     name: jk-bms cell voltage 11
  //     disabled_by_default: false
  //     id: sensor_sensor_id_17
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_12:
  //     name: jk-bms cell voltage 12
  //     disabled_by_default: false
  //     id: sensor_sensor_id_18
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_13:
  //     name: jk-bms cell voltage 13
  //     disabled_by_default: false
  //     id: sensor_sensor_id_19
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_14:
  //     name: jk-bms cell voltage 14
  //     disabled_by_default: false
  //     id: sensor_sensor_id_20
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_15:
  //     name: jk-bms cell voltage 15
  //     disabled_by_default: false
  //     id: sensor_sensor_id_21
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_16:
  //     name: jk-bms cell voltage 16
  //     disabled_by_default: false
  //     id: sensor_sensor_id_22
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_17:
  //     name: jk-bms cell voltage 17
  //     disabled_by_default: false
  //     id: sensor_sensor_id_23
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_18:
  //     name: jk-bms cell voltage 18
  //     disabled_by_default: false
  //     id: sensor_sensor_id_24
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_19:
  //     name: jk-bms cell voltage 19
  //     disabled_by_default: false
  //     id: sensor_sensor_id_25
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_20:
  //     name: jk-bms cell voltage 20
  //     disabled_by_default: false
  //     id: sensor_sensor_id_26
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_21:
  //     name: jk-bms cell voltage 21
  //     disabled_by_default: false
  //     id: sensor_sensor_id_27
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_22:
  //     name: jk-bms cell voltage 22
  //     disabled_by_default: false
  //     id: sensor_sensor_id_28
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_23:
  //     name: jk-bms cell voltage 23
  //     disabled_by_default: false
  //     id: sensor_sensor_id_29
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_voltage_24:
  //     name: jk-bms cell voltage 24
  //     disabled_by_default: false
  //     id: sensor_sensor_id_30
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 3
  //     device_class: voltage
  //     state_class: measurement
  //   cell_resistance_1:
  //     name: jk-bms cell resistance 1
  //     disabled_by_default: false
  //     id: sensor_sensor_id_31
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_2:
  //     name: jk-bms cell resistance 2
  //     disabled_by_default: false
  //     id: sensor_sensor_id_32
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_3:
  //     name: jk-bms cell resistance 3
  //     disabled_by_default: false
  //     id: sensor_sensor_id_33
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_4:
  //     name: jk-bms cell resistance 4
  //     disabled_by_default: false
  //     id: sensor_sensor_id_34
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_5:
  //     name: jk-bms cell resistance 5
  //     disabled_by_default: false
  //     id: sensor_sensor_id_35
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_6:
  //     name: jk-bms cell resistance 6
  //     disabled_by_default: false
  //     id: sensor_sensor_id_36
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_7:
  //     name: jk-bms cell resistance 7
  //     disabled_by_default: false
  //     id: sensor_sensor_id_37
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_8:
  //     name: jk-bms cell resistance 8
  //     disabled_by_default: false
  //     id: sensor_sensor_id_38
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_9:
  //     name: jk-bms cell resistance 9
  //     disabled_by_default: false
  //     id: sensor_sensor_id_39
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_10:
  //     name: jk-bms cell resistance 10
  //     disabled_by_default: false
  //     id: sensor_sensor_id_40
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_11:
  //     name: jk-bms cell resistance 11
  //     disabled_by_default: false
  //     id: sensor_sensor_id_41
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_12:
  //     name: jk-bms cell resistance 12
  //     disabled_by_default: false
  //     id: sensor_sensor_id_42
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_13:
  //     name: jk-bms cell resistance 13
  //     disabled_by_default: false
  //     id: sensor_sensor_id_43
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_14:
  //     name: jk-bms cell resistance 14
  //     disabled_by_default: false
  //     id: sensor_sensor_id_44
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_15:
  //     name: jk-bms cell resistance 15
  //     disabled_by_default: false
  //     id: sensor_sensor_id_45
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_16:
  //     name: jk-bms cell resistance 16
  //     disabled_by_default: false
  //     id: sensor_sensor_id_46
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_17:
  //     name: jk-bms cell resistance 17
  //     disabled_by_default: false
  //     id: sensor_sensor_id_47
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_18:
  //     name: jk-bms cell resistance 18
  //     disabled_by_default: false
  //     id: sensor_sensor_id_48
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_19:
  //     name: jk-bms cell resistance 19
  //     disabled_by_default: false
  //     id: sensor_sensor_id_49
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_20:
  //     name: jk-bms cell resistance 20
  //     disabled_by_default: false
  //     id: sensor_sensor_id_50
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_21:
  //     name: jk-bms cell resistance 21
  //     disabled_by_default: false
  //     id: sensor_sensor_id_51
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_22:
  //     name: jk-bms cell resistance 22
  //     disabled_by_default: false
  //     id: sensor_sensor_id_52
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_23:
  //     name: jk-bms cell resistance 23
  //     disabled_by_default: false
  //     id: sensor_sensor_id_53
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   cell_resistance_24:
  //     name: jk-bms cell resistance 24
  //     disabled_by_default: false
  //     id: sensor_sensor_id_54
  //     force_update: false
  //     unit_of_measurement: Ω
  //     icon: mdi:omega
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   total_voltage:
  //     name: jk-bms total voltage
  //     disabled_by_default: false
  //     id: sensor_sensor_id_55
  //     force_update: false
  //     unit_of_measurement: V
  //     icon: ''
  //     accuracy_decimals: 2
  //     device_class: voltage
  //     state_class: measurement
  //   current:
  //     name: jk-bms current
  //     disabled_by_default: false
  //     id: sensor_sensor_id_56
  //     force_update: false
  //     unit_of_measurement: A
  //     icon: mdi:current-dc
  //     accuracy_decimals: 2
  //     device_class: current
  //     state_class: measurement
  //   heating_current:
  //     name: jk-bms heating current
  //     disabled_by_default: false
  //     id: sensor_sensor_id_57
  //     force_update: false
  //     unit_of_measurement: A
  //     icon: mdi:current-dc
  //     accuracy_decimals: 2
  //     device_class: current
  //     state_class: measurement
  //   power:
  //     name: jk-bms power
  //     disabled_by_default: false
  //     id: sensor_sensor_id_58
  //     force_update: false
  //     unit_of_measurement: W
  //     icon: ''
  //     accuracy_decimals: 2
  //     device_class: power
  //     state_class: measurement
  //   charging_power:
  //     name: jk-bms charging power
  //     disabled_by_default: false
  //     id: sensor_sensor_id_59
  //     force_update: false
  //     unit_of_measurement: W
  //     icon: ''
  //     accuracy_decimals: 2
  //     device_class: power
  //     state_class: measurement
  //   discharging_power:
  //     name: jk-bms discharging power
  //     disabled_by_default: false
  //     id: sensor_sensor_id_60
  //     force_update: false
  //     unit_of_measurement: W
  //     icon: ''
  //     accuracy_decimals: 2
  //     device_class: power
  //     state_class: measurement
  //   temperature_sensor_1:
  //     name: jk-bms temperature sensor 1
  //     disabled_by_default: false
  //     id: sensor_sensor_id_61
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   temperature_sensor_2:
  //     name: jk-bms temperature sensor 2
  //     disabled_by_default: false
  //     id: sensor_sensor_id_62
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   temperature_sensor_3:
  //     name: jk-bms temperature sensor 3
  //     disabled_by_default: false
  //     id: sensor_sensor_id_63
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   temperature_sensor_4:
  //     name: jk-bms temperature sensor 4
  //     disabled_by_default: false
  //     id: sensor_sensor_id_64
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   temperature_sensor_5:
  //     name: jk-bms temperature sensor 5
  //     disabled_by_default: false
  //     id: sensor_sensor_id_65
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   power_tube_temperature:
  //     name: jk-bms power tube temperature
  //     disabled_by_default: false
  //     id: sensor_sensor_id_66
  //     force_update: false
  //     unit_of_measurement: °C
  //     icon: ''
  //     accuracy_decimals: 1
  //     device_class: temperature
  //     state_class: measurement
  //   balancing:
  //     name: jk-bms balancing
  //     disabled_by_default: false
  //     id: sensor_sensor_id_67
  //     force_update: false
  //     unit_of_measurement: ''
  //     icon: mdi:seesaw
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   state_of_charge:
  //     name: jk-bms state of charge
  //     disabled_by_default: false
  //     id: sensor_sensor_id_68
  //     force_update: false
  //     unit_of_measurement: '%'
  //     accuracy_decimals: 0
  //     device_class: battery
  //     state_class: measurement
  //   capacity_remaining:
  //     name: jk-bms capacity remaining
  //     disabled_by_default: false
  //     id: sensor_sensor_id_69
  //     force_update: false
  //     unit_of_measurement: Ah
  //     icon: mdi:battery-50
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   total_battery_capacity_setting:
  //     name: jk-bms total battery capacity setting
  //     disabled_by_default: false
  //     id: sensor_sensor_id_70
  //     force_update: false
  //     unit_of_measurement: Ah
  //     icon: ''
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   charging_cycles:
  //     name: jk-bms charging cycles
  //     disabled_by_default: false
  //     id: sensor_sensor_id_71
  //     force_update: false
  //     unit_of_measurement: ''
  //     icon: mdi:battery-sync
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   total_charging_cycle_capacity:
  //     name: jk-bms total charging cycle capacity
  //     disabled_by_default: false
  //     id: sensor_sensor_id_72
  //     force_update: false
  //     unit_of_measurement: Ah
  //     icon: mdi:counter
  //     accuracy_decimals: 3
  //     device_class: ''
  //     state_class: measurement
  //   total_runtime:
  //     name: jk-bms total runtime
  //     disabled_by_default: false
  //     id: sensor_sensor_id_73
  //     force_update: false
  //     unit_of_measurement: s
  //     icon: mdi:timelapse
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: total_increasing
  //   balancing_current:
  //     name: jk-bms balancing current
  //     disabled_by_default: false
  //     id: sensor_sensor_id_74
  //     force_update: false
  //     unit_of_measurement: A
  //     icon: mdi:current-dc
  //     accuracy_decimals: 2
  //     device_class: current
  //     state_class: measurement
  //   errors_bitmask:
  //     name: jk-bms errors bitmask
  //     disabled_by_default: false
  //     id: sensor_sensor_id_75
  //     force_update: false
  //     unit_of_measurement: ''
  //     icon: mdi:alert-circle-outline
  //     accuracy_decimals: 0
  //     device_class: ''
  //     state_class: measurement
  //   emergency_time_countdown:
  //     name: jk-bms emergency time countdown
  //     disabled_by_default: false
  //     id: sensor_sensor_id_76
  //     force_update: false
  //     unit_of_measurement: s
  //     icon: mdi:timelapse
  //     accuracy_decimals: 0
  //     device_class: ''
  sensor_sensor_id_7 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_7);
  sensor_sensor_id_7->set_name("jk-bms cell voltage 1");
  sensor_sensor_id_7->set_object_id("jk-bms_cell_voltage_1");
  sensor_sensor_id_7->set_disabled_by_default(false);
  sensor_sensor_id_7->set_icon("");
  sensor_sensor_id_7->set_device_class("voltage");
  sensor_sensor_id_7->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_7->set_unit_of_measurement("V");
  sensor_sensor_id_7->set_accuracy_decimals(3);
  sensor_sensor_id_7->set_force_update(false);
  bms0->set_cell_voltage_sensor(0, sensor_sensor_id_7);
  sensor_sensor_id_8 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_8);
  sensor_sensor_id_8->set_name("jk-bms cell voltage 2");
  sensor_sensor_id_8->set_object_id("jk-bms_cell_voltage_2");
  sensor_sensor_id_8->set_disabled_by_default(false);
  sensor_sensor_id_8->set_icon("");
  sensor_sensor_id_8->set_device_class("voltage");
  sensor_sensor_id_8->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_8->set_unit_of_measurement("V");
  sensor_sensor_id_8->set_accuracy_decimals(3);
  sensor_sensor_id_8->set_force_update(false);
  bms0->set_cell_voltage_sensor(1, sensor_sensor_id_8);
  sensor_sensor_id_9 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_9);
  sensor_sensor_id_9->set_name("jk-bms cell voltage 3");
  sensor_sensor_id_9->set_object_id("jk-bms_cell_voltage_3");
  sensor_sensor_id_9->set_disabled_by_default(false);
  sensor_sensor_id_9->set_icon("");
  sensor_sensor_id_9->set_device_class("voltage");
  sensor_sensor_id_9->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_9->set_unit_of_measurement("V");
  sensor_sensor_id_9->set_accuracy_decimals(3);
  sensor_sensor_id_9->set_force_update(false);
  bms0->set_cell_voltage_sensor(2, sensor_sensor_id_9);
  sensor_sensor_id_10 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_10);
  sensor_sensor_id_10->set_name("jk-bms cell voltage 4");
  sensor_sensor_id_10->set_object_id("jk-bms_cell_voltage_4");
  sensor_sensor_id_10->set_disabled_by_default(false);
  sensor_sensor_id_10->set_icon("");
  sensor_sensor_id_10->set_device_class("voltage");
  sensor_sensor_id_10->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_10->set_unit_of_measurement("V");
  sensor_sensor_id_10->set_accuracy_decimals(3);
  sensor_sensor_id_10->set_force_update(false);
  bms0->set_cell_voltage_sensor(3, sensor_sensor_id_10);
  sensor_sensor_id_11 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_11);
  sensor_sensor_id_11->set_name("jk-bms cell voltage 5");
  sensor_sensor_id_11->set_object_id("jk-bms_cell_voltage_5");
  sensor_sensor_id_11->set_disabled_by_default(false);
  sensor_sensor_id_11->set_icon("");
  sensor_sensor_id_11->set_device_class("voltage");
  sensor_sensor_id_11->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_11->set_unit_of_measurement("V");
  sensor_sensor_id_11->set_accuracy_decimals(3);
  sensor_sensor_id_11->set_force_update(false);
  bms0->set_cell_voltage_sensor(4, sensor_sensor_id_11);
  sensor_sensor_id_12 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_12);
  sensor_sensor_id_12->set_name("jk-bms cell voltage 6");
  sensor_sensor_id_12->set_object_id("jk-bms_cell_voltage_6");
  sensor_sensor_id_12->set_disabled_by_default(false);
  sensor_sensor_id_12->set_icon("");
  sensor_sensor_id_12->set_device_class("voltage");
  sensor_sensor_id_12->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_12->set_unit_of_measurement("V");
  sensor_sensor_id_12->set_accuracy_decimals(3);
  sensor_sensor_id_12->set_force_update(false);
  bms0->set_cell_voltage_sensor(5, sensor_sensor_id_12);
  sensor_sensor_id_13 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_13);
  sensor_sensor_id_13->set_name("jk-bms cell voltage 7");
  sensor_sensor_id_13->set_object_id("jk-bms_cell_voltage_7");
  sensor_sensor_id_13->set_disabled_by_default(false);
  sensor_sensor_id_13->set_icon("");
  sensor_sensor_id_13->set_device_class("voltage");
  sensor_sensor_id_13->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_13->set_unit_of_measurement("V");
  sensor_sensor_id_13->set_accuracy_decimals(3);
  sensor_sensor_id_13->set_force_update(false);
  bms0->set_cell_voltage_sensor(6, sensor_sensor_id_13);
  sensor_sensor_id_14 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_14);
  sensor_sensor_id_14->set_name("jk-bms cell voltage 8");
  sensor_sensor_id_14->set_object_id("jk-bms_cell_voltage_8");
  sensor_sensor_id_14->set_disabled_by_default(false);
  sensor_sensor_id_14->set_icon("");
  sensor_sensor_id_14->set_device_class("voltage");
  sensor_sensor_id_14->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_14->set_unit_of_measurement("V");
  sensor_sensor_id_14->set_accuracy_decimals(3);
  sensor_sensor_id_14->set_force_update(false);
  bms0->set_cell_voltage_sensor(7, sensor_sensor_id_14);
  sensor_sensor_id_15 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_15);
  sensor_sensor_id_15->set_name("jk-bms cell voltage 9");
  sensor_sensor_id_15->set_object_id("jk-bms_cell_voltage_9");
  sensor_sensor_id_15->set_disabled_by_default(false);
  sensor_sensor_id_15->set_icon("");
  sensor_sensor_id_15->set_device_class("voltage");
  sensor_sensor_id_15->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_15->set_unit_of_measurement("V");
  sensor_sensor_id_15->set_accuracy_decimals(3);
  sensor_sensor_id_15->set_force_update(false);
  bms0->set_cell_voltage_sensor(8, sensor_sensor_id_15);
  sensor_sensor_id_16 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_16);
  sensor_sensor_id_16->set_name("jk-bms cell voltage 10");
  sensor_sensor_id_16->set_object_id("jk-bms_cell_voltage_10");
  sensor_sensor_id_16->set_disabled_by_default(false);
  sensor_sensor_id_16->set_icon("");
  sensor_sensor_id_16->set_device_class("voltage");
  sensor_sensor_id_16->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_16->set_unit_of_measurement("V");
  sensor_sensor_id_16->set_accuracy_decimals(3);
  sensor_sensor_id_16->set_force_update(false);
  bms0->set_cell_voltage_sensor(9, sensor_sensor_id_16);
  sensor_sensor_id_17 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_17);
  sensor_sensor_id_17->set_name("jk-bms cell voltage 11");
  sensor_sensor_id_17->set_object_id("jk-bms_cell_voltage_11");
  sensor_sensor_id_17->set_disabled_by_default(false);
  sensor_sensor_id_17->set_icon("");
  sensor_sensor_id_17->set_device_class("voltage");
  sensor_sensor_id_17->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_17->set_unit_of_measurement("V");
  sensor_sensor_id_17->set_accuracy_decimals(3);
  sensor_sensor_id_17->set_force_update(false);
  bms0->set_cell_voltage_sensor(10, sensor_sensor_id_17);
  sensor_sensor_id_18 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_18);
  sensor_sensor_id_18->set_name("jk-bms cell voltage 12");
  sensor_sensor_id_18->set_object_id("jk-bms_cell_voltage_12");
  sensor_sensor_id_18->set_disabled_by_default(false);
  sensor_sensor_id_18->set_icon("");
  sensor_sensor_id_18->set_device_class("voltage");
  sensor_sensor_id_18->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_18->set_unit_of_measurement("V");
  sensor_sensor_id_18->set_accuracy_decimals(3);
  sensor_sensor_id_18->set_force_update(false);
  bms0->set_cell_voltage_sensor(11, sensor_sensor_id_18);
  sensor_sensor_id_19 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_19);
  sensor_sensor_id_19->set_name("jk-bms cell voltage 13");
  sensor_sensor_id_19->set_object_id("jk-bms_cell_voltage_13");
  sensor_sensor_id_19->set_disabled_by_default(false);
  sensor_sensor_id_19->set_icon("");
  sensor_sensor_id_19->set_device_class("voltage");
  sensor_sensor_id_19->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_19->set_unit_of_measurement("V");
  sensor_sensor_id_19->set_accuracy_decimals(3);
  sensor_sensor_id_19->set_force_update(false);
  bms0->set_cell_voltage_sensor(12, sensor_sensor_id_19);
  sensor_sensor_id_20 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_20);
  sensor_sensor_id_20->set_name("jk-bms cell voltage 14");
  sensor_sensor_id_20->set_object_id("jk-bms_cell_voltage_14");
  sensor_sensor_id_20->set_disabled_by_default(false);
  sensor_sensor_id_20->set_icon("");
  sensor_sensor_id_20->set_device_class("voltage");
  sensor_sensor_id_20->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_20->set_unit_of_measurement("V");
  sensor_sensor_id_20->set_accuracy_decimals(3);
  sensor_sensor_id_20->set_force_update(false);
  bms0->set_cell_voltage_sensor(13, sensor_sensor_id_20);
  sensor_sensor_id_21 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_21);
  sensor_sensor_id_21->set_name("jk-bms cell voltage 15");
  sensor_sensor_id_21->set_object_id("jk-bms_cell_voltage_15");
  sensor_sensor_id_21->set_disabled_by_default(false);
  sensor_sensor_id_21->set_icon("");
  sensor_sensor_id_21->set_device_class("voltage");
  sensor_sensor_id_21->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_21->set_unit_of_measurement("V");
  sensor_sensor_id_21->set_accuracy_decimals(3);
  sensor_sensor_id_21->set_force_update(false);
  bms0->set_cell_voltage_sensor(14, sensor_sensor_id_21);
  sensor_sensor_id_22 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_22);
  sensor_sensor_id_22->set_name("jk-bms cell voltage 16");
  sensor_sensor_id_22->set_object_id("jk-bms_cell_voltage_16");
  sensor_sensor_id_22->set_disabled_by_default(false);
  sensor_sensor_id_22->set_icon("");
  sensor_sensor_id_22->set_device_class("voltage");
  sensor_sensor_id_22->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_22->set_unit_of_measurement("V");
  sensor_sensor_id_22->set_accuracy_decimals(3);
  sensor_sensor_id_22->set_force_update(false);
  bms0->set_cell_voltage_sensor(15, sensor_sensor_id_22);
  sensor_sensor_id_23 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_23);
  sensor_sensor_id_23->set_name("jk-bms cell voltage 17");
  sensor_sensor_id_23->set_object_id("jk-bms_cell_voltage_17");
  sensor_sensor_id_23->set_disabled_by_default(false);
  sensor_sensor_id_23->set_icon("");
  sensor_sensor_id_23->set_device_class("voltage");
  sensor_sensor_id_23->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_23->set_unit_of_measurement("V");
  sensor_sensor_id_23->set_accuracy_decimals(3);
  sensor_sensor_id_23->set_force_update(false);
  bms0->set_cell_voltage_sensor(16, sensor_sensor_id_23);
  sensor_sensor_id_24 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_24);
  sensor_sensor_id_24->set_name("jk-bms cell voltage 18");
  sensor_sensor_id_24->set_object_id("jk-bms_cell_voltage_18");
  sensor_sensor_id_24->set_disabled_by_default(false);
  sensor_sensor_id_24->set_icon("");
  sensor_sensor_id_24->set_device_class("voltage");
  sensor_sensor_id_24->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_24->set_unit_of_measurement("V");
  sensor_sensor_id_24->set_accuracy_decimals(3);
  sensor_sensor_id_24->set_force_update(false);
  bms0->set_cell_voltage_sensor(17, sensor_sensor_id_24);
  sensor_sensor_id_25 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_25);
  sensor_sensor_id_25->set_name("jk-bms cell voltage 19");
  sensor_sensor_id_25->set_object_id("jk-bms_cell_voltage_19");
  sensor_sensor_id_25->set_disabled_by_default(false);
  sensor_sensor_id_25->set_icon("");
  sensor_sensor_id_25->set_device_class("voltage");
  sensor_sensor_id_25->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_25->set_unit_of_measurement("V");
  sensor_sensor_id_25->set_accuracy_decimals(3);
  sensor_sensor_id_25->set_force_update(false);
  bms0->set_cell_voltage_sensor(18, sensor_sensor_id_25);
  sensor_sensor_id_26 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_26);
  sensor_sensor_id_26->set_name("jk-bms cell voltage 20");
  sensor_sensor_id_26->set_object_id("jk-bms_cell_voltage_20");
  sensor_sensor_id_26->set_disabled_by_default(false);
  sensor_sensor_id_26->set_icon("");
  sensor_sensor_id_26->set_device_class("voltage");
  sensor_sensor_id_26->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_26->set_unit_of_measurement("V");
  sensor_sensor_id_26->set_accuracy_decimals(3);
  sensor_sensor_id_26->set_force_update(false);
  bms0->set_cell_voltage_sensor(19, sensor_sensor_id_26);
  sensor_sensor_id_27 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_27);
  sensor_sensor_id_27->set_name("jk-bms cell voltage 21");
  sensor_sensor_id_27->set_object_id("jk-bms_cell_voltage_21");
  sensor_sensor_id_27->set_disabled_by_default(false);
  sensor_sensor_id_27->set_icon("");
  sensor_sensor_id_27->set_device_class("voltage");
  sensor_sensor_id_27->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_27->set_unit_of_measurement("V");
  sensor_sensor_id_27->set_accuracy_decimals(3);
  sensor_sensor_id_27->set_force_update(false);
  bms0->set_cell_voltage_sensor(20, sensor_sensor_id_27);
  sensor_sensor_id_28 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_28);
  sensor_sensor_id_28->set_name("jk-bms cell voltage 22");
  sensor_sensor_id_28->set_object_id("jk-bms_cell_voltage_22");
  sensor_sensor_id_28->set_disabled_by_default(false);
  sensor_sensor_id_28->set_icon("");
  sensor_sensor_id_28->set_device_class("voltage");
  sensor_sensor_id_28->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_28->set_unit_of_measurement("V");
  sensor_sensor_id_28->set_accuracy_decimals(3);
  sensor_sensor_id_28->set_force_update(false);
  bms0->set_cell_voltage_sensor(21, sensor_sensor_id_28);
  sensor_sensor_id_29 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_29);
  sensor_sensor_id_29->set_name("jk-bms cell voltage 23");
  sensor_sensor_id_29->set_object_id("jk-bms_cell_voltage_23");
  sensor_sensor_id_29->set_disabled_by_default(false);
  sensor_sensor_id_29->set_icon("");
  sensor_sensor_id_29->set_device_class("voltage");
  sensor_sensor_id_29->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_29->set_unit_of_measurement("V");
  sensor_sensor_id_29->set_accuracy_decimals(3);
  sensor_sensor_id_29->set_force_update(false);
  bms0->set_cell_voltage_sensor(22, sensor_sensor_id_29);
  sensor_sensor_id_30 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_30);
  sensor_sensor_id_30->set_name("jk-bms cell voltage 24");
  sensor_sensor_id_30->set_object_id("jk-bms_cell_voltage_24");
  sensor_sensor_id_30->set_disabled_by_default(false);
  sensor_sensor_id_30->set_icon("");
  sensor_sensor_id_30->set_device_class("voltage");
  sensor_sensor_id_30->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_30->set_unit_of_measurement("V");
  sensor_sensor_id_30->set_accuracy_decimals(3);
  sensor_sensor_id_30->set_force_update(false);
  bms0->set_cell_voltage_sensor(23, sensor_sensor_id_30);
  sensor_sensor_id_31 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_31);
  sensor_sensor_id_31->set_name("jk-bms cell resistance 1");
  sensor_sensor_id_31->set_object_id("jk-bms_cell_resistance_1");
  sensor_sensor_id_31->set_disabled_by_default(false);
  sensor_sensor_id_31->set_icon("mdi:omega");
  sensor_sensor_id_31->set_device_class("");
  sensor_sensor_id_31->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_31->set_unit_of_measurement("\316\251");
  sensor_sensor_id_31->set_accuracy_decimals(3);
  sensor_sensor_id_31->set_force_update(false);
  bms0->set_cell_resistance_sensor(0, sensor_sensor_id_31);
  sensor_sensor_id_32 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_32);
  sensor_sensor_id_32->set_name("jk-bms cell resistance 2");
  sensor_sensor_id_32->set_object_id("jk-bms_cell_resistance_2");
  sensor_sensor_id_32->set_disabled_by_default(false);
  sensor_sensor_id_32->set_icon("mdi:omega");
  sensor_sensor_id_32->set_device_class("");
  sensor_sensor_id_32->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_32->set_unit_of_measurement("\316\251");
  sensor_sensor_id_32->set_accuracy_decimals(3);
  sensor_sensor_id_32->set_force_update(false);
  bms0->set_cell_resistance_sensor(1, sensor_sensor_id_32);
  sensor_sensor_id_33 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_33);
  sensor_sensor_id_33->set_name("jk-bms cell resistance 3");
  sensor_sensor_id_33->set_object_id("jk-bms_cell_resistance_3");
  sensor_sensor_id_33->set_disabled_by_default(false);
  sensor_sensor_id_33->set_icon("mdi:omega");
  sensor_sensor_id_33->set_device_class("");
  sensor_sensor_id_33->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_33->set_unit_of_measurement("\316\251");
  sensor_sensor_id_33->set_accuracy_decimals(3);
  sensor_sensor_id_33->set_force_update(false);
  bms0->set_cell_resistance_sensor(2, sensor_sensor_id_33);
  sensor_sensor_id_34 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_34);
  sensor_sensor_id_34->set_name("jk-bms cell resistance 4");
  sensor_sensor_id_34->set_object_id("jk-bms_cell_resistance_4");
  sensor_sensor_id_34->set_disabled_by_default(false);
  sensor_sensor_id_34->set_icon("mdi:omega");
  sensor_sensor_id_34->set_device_class("");
  sensor_sensor_id_34->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_34->set_unit_of_measurement("\316\251");
  sensor_sensor_id_34->set_accuracy_decimals(3);
  sensor_sensor_id_34->set_force_update(false);
  bms0->set_cell_resistance_sensor(3, sensor_sensor_id_34);
  sensor_sensor_id_35 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_35);
  sensor_sensor_id_35->set_name("jk-bms cell resistance 5");
  sensor_sensor_id_35->set_object_id("jk-bms_cell_resistance_5");
  sensor_sensor_id_35->set_disabled_by_default(false);
  sensor_sensor_id_35->set_icon("mdi:omega");
  sensor_sensor_id_35->set_device_class("");
  sensor_sensor_id_35->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_35->set_unit_of_measurement("\316\251");
  sensor_sensor_id_35->set_accuracy_decimals(3);
  sensor_sensor_id_35->set_force_update(false);
  bms0->set_cell_resistance_sensor(4, sensor_sensor_id_35);
  sensor_sensor_id_36 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_36);
  sensor_sensor_id_36->set_name("jk-bms cell resistance 6");
  sensor_sensor_id_36->set_object_id("jk-bms_cell_resistance_6");
  sensor_sensor_id_36->set_disabled_by_default(false);
  sensor_sensor_id_36->set_icon("mdi:omega");
  sensor_sensor_id_36->set_device_class("");
  sensor_sensor_id_36->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_36->set_unit_of_measurement("\316\251");
  sensor_sensor_id_36->set_accuracy_decimals(3);
  sensor_sensor_id_36->set_force_update(false);
  bms0->set_cell_resistance_sensor(5, sensor_sensor_id_36);
  sensor_sensor_id_37 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_37);
  sensor_sensor_id_37->set_name("jk-bms cell resistance 7");
  sensor_sensor_id_37->set_object_id("jk-bms_cell_resistance_7");
  sensor_sensor_id_37->set_disabled_by_default(false);
  sensor_sensor_id_37->set_icon("mdi:omega");
  sensor_sensor_id_37->set_device_class("");
  sensor_sensor_id_37->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_37->set_unit_of_measurement("\316\251");
  sensor_sensor_id_37->set_accuracy_decimals(3);
  sensor_sensor_id_37->set_force_update(false);
  bms0->set_cell_resistance_sensor(6, sensor_sensor_id_37);
  sensor_sensor_id_38 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_38);
  sensor_sensor_id_38->set_name("jk-bms cell resistance 8");
  sensor_sensor_id_38->set_object_id("jk-bms_cell_resistance_8");
  sensor_sensor_id_38->set_disabled_by_default(false);
  sensor_sensor_id_38->set_icon("mdi:omega");
  sensor_sensor_id_38->set_device_class("");
  sensor_sensor_id_38->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_38->set_unit_of_measurement("\316\251");
  sensor_sensor_id_38->set_accuracy_decimals(3);
  sensor_sensor_id_38->set_force_update(false);
  bms0->set_cell_resistance_sensor(7, sensor_sensor_id_38);
  sensor_sensor_id_39 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_39);
  sensor_sensor_id_39->set_name("jk-bms cell resistance 9");
  sensor_sensor_id_39->set_object_id("jk-bms_cell_resistance_9");
  sensor_sensor_id_39->set_disabled_by_default(false);
  sensor_sensor_id_39->set_icon("mdi:omega");
  sensor_sensor_id_39->set_device_class("");
  sensor_sensor_id_39->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_39->set_unit_of_measurement("\316\251");
  sensor_sensor_id_39->set_accuracy_decimals(3);
  sensor_sensor_id_39->set_force_update(false);
  bms0->set_cell_resistance_sensor(8, sensor_sensor_id_39);
  sensor_sensor_id_40 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_40);
  sensor_sensor_id_40->set_name("jk-bms cell resistance 10");
  sensor_sensor_id_40->set_object_id("jk-bms_cell_resistance_10");
  sensor_sensor_id_40->set_disabled_by_default(false);
  sensor_sensor_id_40->set_icon("mdi:omega");
  sensor_sensor_id_40->set_device_class("");
  sensor_sensor_id_40->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_40->set_unit_of_measurement("\316\251");
  sensor_sensor_id_40->set_accuracy_decimals(3);
  sensor_sensor_id_40->set_force_update(false);
  bms0->set_cell_resistance_sensor(9, sensor_sensor_id_40);
  sensor_sensor_id_41 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_41);
  sensor_sensor_id_41->set_name("jk-bms cell resistance 11");
  sensor_sensor_id_41->set_object_id("jk-bms_cell_resistance_11");
  sensor_sensor_id_41->set_disabled_by_default(false);
  sensor_sensor_id_41->set_icon("mdi:omega");
  sensor_sensor_id_41->set_device_class("");
  sensor_sensor_id_41->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_41->set_unit_of_measurement("\316\251");
  sensor_sensor_id_41->set_accuracy_decimals(3);
  sensor_sensor_id_41->set_force_update(false);
  bms0->set_cell_resistance_sensor(10, sensor_sensor_id_41);
  sensor_sensor_id_42 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_42);
  sensor_sensor_id_42->set_name("jk-bms cell resistance 12");
  sensor_sensor_id_42->set_object_id("jk-bms_cell_resistance_12");
  sensor_sensor_id_42->set_disabled_by_default(false);
  sensor_sensor_id_42->set_icon("mdi:omega");
  sensor_sensor_id_42->set_device_class("");
  sensor_sensor_id_42->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_42->set_unit_of_measurement("\316\251");
  sensor_sensor_id_42->set_accuracy_decimals(3);
  sensor_sensor_id_42->set_force_update(false);
  bms0->set_cell_resistance_sensor(11, sensor_sensor_id_42);
  sensor_sensor_id_43 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_43);
  sensor_sensor_id_43->set_name("jk-bms cell resistance 13");
  sensor_sensor_id_43->set_object_id("jk-bms_cell_resistance_13");
  sensor_sensor_id_43->set_disabled_by_default(false);
  sensor_sensor_id_43->set_icon("mdi:omega");
  sensor_sensor_id_43->set_device_class("");
  sensor_sensor_id_43->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_43->set_unit_of_measurement("\316\251");
  sensor_sensor_id_43->set_accuracy_decimals(3);
  sensor_sensor_id_43->set_force_update(false);
  bms0->set_cell_resistance_sensor(12, sensor_sensor_id_43);
  sensor_sensor_id_44 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_44);
  sensor_sensor_id_44->set_name("jk-bms cell resistance 14");
  sensor_sensor_id_44->set_object_id("jk-bms_cell_resistance_14");
  sensor_sensor_id_44->set_disabled_by_default(false);
  sensor_sensor_id_44->set_icon("mdi:omega");
  sensor_sensor_id_44->set_device_class("");
  sensor_sensor_id_44->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_44->set_unit_of_measurement("\316\251");
  sensor_sensor_id_44->set_accuracy_decimals(3);
  sensor_sensor_id_44->set_force_update(false);
  bms0->set_cell_resistance_sensor(13, sensor_sensor_id_44);
  sensor_sensor_id_45 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_45);
  sensor_sensor_id_45->set_name("jk-bms cell resistance 15");
  sensor_sensor_id_45->set_object_id("jk-bms_cell_resistance_15");
  sensor_sensor_id_45->set_disabled_by_default(false);
  sensor_sensor_id_45->set_icon("mdi:omega");
  sensor_sensor_id_45->set_device_class("");
  sensor_sensor_id_45->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_45->set_unit_of_measurement("\316\251");
  sensor_sensor_id_45->set_accuracy_decimals(3);
  sensor_sensor_id_45->set_force_update(false);
  bms0->set_cell_resistance_sensor(14, sensor_sensor_id_45);
  sensor_sensor_id_46 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_46);
  sensor_sensor_id_46->set_name("jk-bms cell resistance 16");
  sensor_sensor_id_46->set_object_id("jk-bms_cell_resistance_16");
  sensor_sensor_id_46->set_disabled_by_default(false);
  sensor_sensor_id_46->set_icon("mdi:omega");
  sensor_sensor_id_46->set_device_class("");
  sensor_sensor_id_46->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_46->set_unit_of_measurement("\316\251");
  sensor_sensor_id_46->set_accuracy_decimals(3);
  sensor_sensor_id_46->set_force_update(false);
  bms0->set_cell_resistance_sensor(15, sensor_sensor_id_46);
  sensor_sensor_id_47 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_47);
  sensor_sensor_id_47->set_name("jk-bms cell resistance 17");
  sensor_sensor_id_47->set_object_id("jk-bms_cell_resistance_17");
  sensor_sensor_id_47->set_disabled_by_default(false);
  sensor_sensor_id_47->set_icon("mdi:omega");
  sensor_sensor_id_47->set_device_class("");
  sensor_sensor_id_47->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_47->set_unit_of_measurement("\316\251");
  sensor_sensor_id_47->set_accuracy_decimals(3);
  sensor_sensor_id_47->set_force_update(false);
  bms0->set_cell_resistance_sensor(16, sensor_sensor_id_47);
  sensor_sensor_id_48 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_48);
  sensor_sensor_id_48->set_name("jk-bms cell resistance 18");
  sensor_sensor_id_48->set_object_id("jk-bms_cell_resistance_18");
  sensor_sensor_id_48->set_disabled_by_default(false);
  sensor_sensor_id_48->set_icon("mdi:omega");
  sensor_sensor_id_48->set_device_class("");
  sensor_sensor_id_48->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_48->set_unit_of_measurement("\316\251");
  sensor_sensor_id_48->set_accuracy_decimals(3);
  sensor_sensor_id_48->set_force_update(false);
  bms0->set_cell_resistance_sensor(17, sensor_sensor_id_48);
  sensor_sensor_id_49 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_49);
  sensor_sensor_id_49->set_name("jk-bms cell resistance 19");
  sensor_sensor_id_49->set_object_id("jk-bms_cell_resistance_19");
  sensor_sensor_id_49->set_disabled_by_default(false);
  sensor_sensor_id_49->set_icon("mdi:omega");
  sensor_sensor_id_49->set_device_class("");
  sensor_sensor_id_49->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_49->set_unit_of_measurement("\316\251");
  sensor_sensor_id_49->set_accuracy_decimals(3);
  sensor_sensor_id_49->set_force_update(false);
  bms0->set_cell_resistance_sensor(18, sensor_sensor_id_49);
  sensor_sensor_id_50 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_50);
  sensor_sensor_id_50->set_name("jk-bms cell resistance 20");
  sensor_sensor_id_50->set_object_id("jk-bms_cell_resistance_20");
  sensor_sensor_id_50->set_disabled_by_default(false);
  sensor_sensor_id_50->set_icon("mdi:omega");
  sensor_sensor_id_50->set_device_class("");
  sensor_sensor_id_50->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_50->set_unit_of_measurement("\316\251");
  sensor_sensor_id_50->set_accuracy_decimals(3);
  sensor_sensor_id_50->set_force_update(false);
  bms0->set_cell_resistance_sensor(19, sensor_sensor_id_50);
  sensor_sensor_id_51 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_51);
  sensor_sensor_id_51->set_name("jk-bms cell resistance 21");
  sensor_sensor_id_51->set_object_id("jk-bms_cell_resistance_21");
  sensor_sensor_id_51->set_disabled_by_default(false);
  sensor_sensor_id_51->set_icon("mdi:omega");
  sensor_sensor_id_51->set_device_class("");
  sensor_sensor_id_51->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_51->set_unit_of_measurement("\316\251");
  sensor_sensor_id_51->set_accuracy_decimals(3);
  sensor_sensor_id_51->set_force_update(false);
  bms0->set_cell_resistance_sensor(20, sensor_sensor_id_51);
  sensor_sensor_id_52 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_52);
  sensor_sensor_id_52->set_name("jk-bms cell resistance 22");
  sensor_sensor_id_52->set_object_id("jk-bms_cell_resistance_22");
  sensor_sensor_id_52->set_disabled_by_default(false);
  sensor_sensor_id_52->set_icon("mdi:omega");
  sensor_sensor_id_52->set_device_class("");
  sensor_sensor_id_52->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_52->set_unit_of_measurement("\316\251");
  sensor_sensor_id_52->set_accuracy_decimals(3);
  sensor_sensor_id_52->set_force_update(false);
  bms0->set_cell_resistance_sensor(21, sensor_sensor_id_52);
  sensor_sensor_id_53 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_53);
  sensor_sensor_id_53->set_name("jk-bms cell resistance 23");
  sensor_sensor_id_53->set_object_id("jk-bms_cell_resistance_23");
  sensor_sensor_id_53->set_disabled_by_default(false);
  sensor_sensor_id_53->set_icon("mdi:omega");
  sensor_sensor_id_53->set_device_class("");
  sensor_sensor_id_53->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_53->set_unit_of_measurement("\316\251");
  sensor_sensor_id_53->set_accuracy_decimals(3);
  sensor_sensor_id_53->set_force_update(false);
  bms0->set_cell_resistance_sensor(22, sensor_sensor_id_53);
  sensor_sensor_id_54 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_54);
  sensor_sensor_id_54->set_name("jk-bms cell resistance 24");
  sensor_sensor_id_54->set_object_id("jk-bms_cell_resistance_24");
  sensor_sensor_id_54->set_disabled_by_default(false);
  sensor_sensor_id_54->set_icon("mdi:omega");
  sensor_sensor_id_54->set_device_class("");
  sensor_sensor_id_54->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_54->set_unit_of_measurement("\316\251");
  sensor_sensor_id_54->set_accuracy_decimals(3);
  sensor_sensor_id_54->set_force_update(false);
  bms0->set_cell_resistance_sensor(23, sensor_sensor_id_54);
  sensor_sensor_id_61 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_61);
  sensor_sensor_id_61->set_name("jk-bms temperature sensor 1");
  sensor_sensor_id_61->set_object_id("jk-bms_temperature_sensor_1");
  sensor_sensor_id_61->set_disabled_by_default(false);
  sensor_sensor_id_61->set_icon("");
  sensor_sensor_id_61->set_device_class("temperature");
  sensor_sensor_id_61->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_61->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_61->set_accuracy_decimals(1);
  sensor_sensor_id_61->set_force_update(false);
  bms0->set_temperature_sensor(0, sensor_sensor_id_61);
  sensor_sensor_id_62 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_62);
  sensor_sensor_id_62->set_name("jk-bms temperature sensor 2");
  sensor_sensor_id_62->set_object_id("jk-bms_temperature_sensor_2");
  sensor_sensor_id_62->set_disabled_by_default(false);
  sensor_sensor_id_62->set_icon("");
  sensor_sensor_id_62->set_device_class("temperature");
  sensor_sensor_id_62->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_62->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_62->set_accuracy_decimals(1);
  sensor_sensor_id_62->set_force_update(false);
  bms0->set_temperature_sensor(1, sensor_sensor_id_62);
  sensor_sensor_id_63 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_63);
  sensor_sensor_id_63->set_name("jk-bms temperature sensor 3");
  sensor_sensor_id_63->set_object_id("jk-bms_temperature_sensor_3");
  sensor_sensor_id_63->set_disabled_by_default(false);
  sensor_sensor_id_63->set_icon("");
  sensor_sensor_id_63->set_device_class("temperature");
  sensor_sensor_id_63->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_63->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_63->set_accuracy_decimals(1);
  sensor_sensor_id_63->set_force_update(false);
  bms0->set_temperature_sensor(2, sensor_sensor_id_63);
  sensor_sensor_id_64 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_64);
  sensor_sensor_id_64->set_name("jk-bms temperature sensor 4");
  sensor_sensor_id_64->set_object_id("jk-bms_temperature_sensor_4");
  sensor_sensor_id_64->set_disabled_by_default(false);
  sensor_sensor_id_64->set_icon("");
  sensor_sensor_id_64->set_device_class("temperature");
  sensor_sensor_id_64->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_64->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_64->set_accuracy_decimals(1);
  sensor_sensor_id_64->set_force_update(false);
  bms0->set_temperature_sensor(3, sensor_sensor_id_64);
  sensor_sensor_id_65 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_65);
  sensor_sensor_id_65->set_name("jk-bms temperature sensor 5");
  sensor_sensor_id_65->set_object_id("jk-bms_temperature_sensor_5");
  sensor_sensor_id_65->set_disabled_by_default(false);
  sensor_sensor_id_65->set_icon("");
  sensor_sensor_id_65->set_device_class("temperature");
  sensor_sensor_id_65->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_65->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_65->set_accuracy_decimals(1);
  sensor_sensor_id_65->set_force_update(false);
  bms0->set_temperature_sensor(4, sensor_sensor_id_65);
  sensor_sensor_id_67 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_67);
  sensor_sensor_id_67->set_name("jk-bms balancing");
  sensor_sensor_id_67->set_object_id("jk-bms_balancing");
  sensor_sensor_id_67->set_disabled_by_default(false);
  sensor_sensor_id_67->set_icon("mdi:seesaw");
  sensor_sensor_id_67->set_device_class("");
  sensor_sensor_id_67->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_67->set_unit_of_measurement("");
  sensor_sensor_id_67->set_accuracy_decimals(0);
  sensor_sensor_id_67->set_force_update(false);
  bms0->set_balancing_sensor(sensor_sensor_id_67);
  sensor_sensor_id = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id);
  sensor_sensor_id->set_name("jk-bms min cell voltage");
  sensor_sensor_id->set_object_id("jk-bms_min_cell_voltage");
  sensor_sensor_id->set_disabled_by_default(false);
  sensor_sensor_id->set_icon("");
  sensor_sensor_id->set_device_class("voltage");
  sensor_sensor_id->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id->set_unit_of_measurement("V");
  sensor_sensor_id->set_accuracy_decimals(3);
  sensor_sensor_id->set_force_update(false);
  bms0->set_min_cell_voltage_sensor(sensor_sensor_id);
  sensor_sensor_id_2 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_2);
  sensor_sensor_id_2->set_name("jk-bms max cell voltage");
  sensor_sensor_id_2->set_object_id("jk-bms_max_cell_voltage");
  sensor_sensor_id_2->set_disabled_by_default(false);
  sensor_sensor_id_2->set_icon("");
  sensor_sensor_id_2->set_device_class("voltage");
  sensor_sensor_id_2->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_2->set_unit_of_measurement("V");
  sensor_sensor_id_2->set_accuracy_decimals(3);
  sensor_sensor_id_2->set_force_update(false);
  bms0->set_max_cell_voltage_sensor(sensor_sensor_id_2);
  sensor_sensor_id_3 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_3);
  sensor_sensor_id_3->set_name("jk-bms min voltage cell");
  sensor_sensor_id_3->set_object_id("jk-bms_min_voltage_cell");
  sensor_sensor_id_3->set_disabled_by_default(false);
  sensor_sensor_id_3->set_icon("mdi:battery-minus-outline");
  sensor_sensor_id_3->set_device_class("");
  sensor_sensor_id_3->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_3->set_unit_of_measurement("");
  sensor_sensor_id_3->set_accuracy_decimals(0);
  sensor_sensor_id_3->set_force_update(false);
  bms0->set_min_voltage_cell_sensor(sensor_sensor_id_3);
  sensor_sensor_id_4 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_4);
  sensor_sensor_id_4->set_name("jk-bms max voltage cell");
  sensor_sensor_id_4->set_object_id("jk-bms_max_voltage_cell");
  sensor_sensor_id_4->set_disabled_by_default(false);
  sensor_sensor_id_4->set_icon("mdi:battery-plus-outline");
  sensor_sensor_id_4->set_device_class("");
  sensor_sensor_id_4->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_4->set_unit_of_measurement("");
  sensor_sensor_id_4->set_accuracy_decimals(0);
  sensor_sensor_id_4->set_force_update(false);
  bms0->set_max_voltage_cell_sensor(sensor_sensor_id_4);
  sensor_sensor_id_5 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_5);
  sensor_sensor_id_5->set_name("jk-bms delta cell voltage");
  sensor_sensor_id_5->set_object_id("jk-bms_delta_cell_voltage");
  sensor_sensor_id_5->set_disabled_by_default(false);
  sensor_sensor_id_5->set_icon("");
  sensor_sensor_id_5->set_device_class("voltage");
  sensor_sensor_id_5->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_5->set_unit_of_measurement("V");
  sensor_sensor_id_5->set_accuracy_decimals(3);
  sensor_sensor_id_5->set_force_update(false);
  bms0->set_delta_cell_voltage_sensor(sensor_sensor_id_5);
  sensor_sensor_id_6 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_6);
  sensor_sensor_id_6->set_name("jk-bms average cell voltage");
  sensor_sensor_id_6->set_object_id("jk-bms_average_cell_voltage");
  sensor_sensor_id_6->set_disabled_by_default(false);
  sensor_sensor_id_6->set_icon("");
  sensor_sensor_id_6->set_device_class("voltage");
  sensor_sensor_id_6->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_6->set_unit_of_measurement("V");
  sensor_sensor_id_6->set_accuracy_decimals(3);
  sensor_sensor_id_6->set_force_update(false);
  bms0->set_average_cell_voltage_sensor(sensor_sensor_id_6);
  sensor_sensor_id_55 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_55);
  sensor_sensor_id_55->set_name("jk-bms total voltage");
  sensor_sensor_id_55->set_object_id("jk-bms_total_voltage");
  sensor_sensor_id_55->set_disabled_by_default(false);
  sensor_sensor_id_55->set_icon("");
  sensor_sensor_id_55->set_device_class("voltage");
  sensor_sensor_id_55->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_55->set_unit_of_measurement("V");
  sensor_sensor_id_55->set_accuracy_decimals(2);
  sensor_sensor_id_55->set_force_update(false);
  bms0->set_total_voltage_sensor(sensor_sensor_id_55);
  sensor_sensor_id_56 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_56);
  sensor_sensor_id_56->set_name("jk-bms current");
  sensor_sensor_id_56->set_object_id("jk-bms_current");
  sensor_sensor_id_56->set_disabled_by_default(false);
  sensor_sensor_id_56->set_icon("mdi:current-dc");
  sensor_sensor_id_56->set_device_class("current");
  sensor_sensor_id_56->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_56->set_unit_of_measurement("A");
  sensor_sensor_id_56->set_accuracy_decimals(2);
  sensor_sensor_id_56->set_force_update(false);
  bms0->set_current_sensor(sensor_sensor_id_56);
  sensor_sensor_id_58 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_58);
  sensor_sensor_id_58->set_name("jk-bms power");
  sensor_sensor_id_58->set_object_id("jk-bms_power");
  sensor_sensor_id_58->set_disabled_by_default(false);
  sensor_sensor_id_58->set_icon("");
  sensor_sensor_id_58->set_device_class("power");
  sensor_sensor_id_58->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_58->set_unit_of_measurement("W");
  sensor_sensor_id_58->set_accuracy_decimals(2);
  sensor_sensor_id_58->set_force_update(false);
  bms0->set_power_sensor(sensor_sensor_id_58);
  sensor_sensor_id_59 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_59);
  sensor_sensor_id_59->set_name("jk-bms charging power");
  sensor_sensor_id_59->set_object_id("jk-bms_charging_power");
  sensor_sensor_id_59->set_disabled_by_default(false);
  sensor_sensor_id_59->set_icon("");
  sensor_sensor_id_59->set_device_class("power");
  sensor_sensor_id_59->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_59->set_unit_of_measurement("W");
  sensor_sensor_id_59->set_accuracy_decimals(2);
  sensor_sensor_id_59->set_force_update(false);
  bms0->set_charging_power_sensor(sensor_sensor_id_59);
  sensor_sensor_id_60 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_60);
  sensor_sensor_id_60->set_name("jk-bms discharging power");
  sensor_sensor_id_60->set_object_id("jk-bms_discharging_power");
  sensor_sensor_id_60->set_disabled_by_default(false);
  sensor_sensor_id_60->set_icon("");
  sensor_sensor_id_60->set_device_class("power");
  sensor_sensor_id_60->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_60->set_unit_of_measurement("W");
  sensor_sensor_id_60->set_accuracy_decimals(2);
  sensor_sensor_id_60->set_force_update(false);
  bms0->set_discharging_power_sensor(sensor_sensor_id_60);
  sensor_sensor_id_66 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_66);
  sensor_sensor_id_66->set_name("jk-bms power tube temperature");
  sensor_sensor_id_66->set_object_id("jk-bms_power_tube_temperature");
  sensor_sensor_id_66->set_disabled_by_default(false);
  sensor_sensor_id_66->set_icon("");
  sensor_sensor_id_66->set_device_class("temperature");
  sensor_sensor_id_66->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_66->set_unit_of_measurement("\302\260C");
  sensor_sensor_id_66->set_accuracy_decimals(1);
  sensor_sensor_id_66->set_force_update(false);
  bms0->set_power_tube_temperature_sensor(sensor_sensor_id_66);
  sensor_sensor_id_68 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_68);
  sensor_sensor_id_68->set_name("jk-bms state of charge");
  sensor_sensor_id_68->set_object_id("jk-bms_state_of_charge");
  sensor_sensor_id_68->set_disabled_by_default(false);
  sensor_sensor_id_68->set_device_class("battery");
  sensor_sensor_id_68->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_68->set_unit_of_measurement("%");
  sensor_sensor_id_68->set_accuracy_decimals(0);
  sensor_sensor_id_68->set_force_update(false);
  bms0->set_state_of_charge_sensor(sensor_sensor_id_68);
  sensor_sensor_id_69 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_69);
  sensor_sensor_id_69->set_name("jk-bms capacity remaining");
  sensor_sensor_id_69->set_object_id("jk-bms_capacity_remaining");
  sensor_sensor_id_69->set_disabled_by_default(false);
  sensor_sensor_id_69->set_icon("mdi:battery-50");
  sensor_sensor_id_69->set_device_class("");
  sensor_sensor_id_69->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_69->set_unit_of_measurement("Ah");
  sensor_sensor_id_69->set_accuracy_decimals(3);
  sensor_sensor_id_69->set_force_update(false);
  bms0->set_capacity_remaining_sensor(sensor_sensor_id_69);
  sensor_sensor_id_70 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_70);
  sensor_sensor_id_70->set_name("jk-bms total battery capacity setting");
  sensor_sensor_id_70->set_object_id("jk-bms_total_battery_capacity_setting");
  sensor_sensor_id_70->set_disabled_by_default(false);
  sensor_sensor_id_70->set_icon("");
  sensor_sensor_id_70->set_device_class("");
  sensor_sensor_id_70->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_70->set_unit_of_measurement("Ah");
  sensor_sensor_id_70->set_accuracy_decimals(0);
  sensor_sensor_id_70->set_force_update(false);
  bms0->set_total_battery_capacity_setting_sensor(sensor_sensor_id_70);
  sensor_sensor_id_71 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_71);
  sensor_sensor_id_71->set_name("jk-bms charging cycles");
  sensor_sensor_id_71->set_object_id("jk-bms_charging_cycles");
  sensor_sensor_id_71->set_disabled_by_default(false);
  sensor_sensor_id_71->set_icon("mdi:battery-sync");
  sensor_sensor_id_71->set_device_class("");
  sensor_sensor_id_71->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_71->set_unit_of_measurement("");
  sensor_sensor_id_71->set_accuracy_decimals(0);
  sensor_sensor_id_71->set_force_update(false);
  bms0->set_charging_cycles_sensor(sensor_sensor_id_71);
  sensor_sensor_id_72 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_72);
  sensor_sensor_id_72->set_name("jk-bms total charging cycle capacity");
  sensor_sensor_id_72->set_object_id("jk-bms_total_charging_cycle_capacity");
  sensor_sensor_id_72->set_disabled_by_default(false);
  sensor_sensor_id_72->set_icon("mdi:counter");
  sensor_sensor_id_72->set_device_class("");
  sensor_sensor_id_72->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_72->set_unit_of_measurement("Ah");
  sensor_sensor_id_72->set_accuracy_decimals(3);
  sensor_sensor_id_72->set_force_update(false);
  bms0->set_total_charging_cycle_capacity_sensor(sensor_sensor_id_72);
  sensor_sensor_id_73 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_73);
  sensor_sensor_id_73->set_name("jk-bms total runtime");
  sensor_sensor_id_73->set_object_id("jk-bms_total_runtime");
  sensor_sensor_id_73->set_disabled_by_default(false);
  sensor_sensor_id_73->set_icon("mdi:timelapse");
  sensor_sensor_id_73->set_device_class("");
  sensor_sensor_id_73->set_state_class(sensor::STATE_CLASS_TOTAL_INCREASING);
  sensor_sensor_id_73->set_unit_of_measurement("s");
  sensor_sensor_id_73->set_accuracy_decimals(0);
  sensor_sensor_id_73->set_force_update(false);
  bms0->set_total_runtime_sensor(sensor_sensor_id_73);
  sensor_sensor_id_74 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_74);
  sensor_sensor_id_74->set_name("jk-bms balancing current");
  sensor_sensor_id_74->set_object_id("jk-bms_balancing_current");
  sensor_sensor_id_74->set_disabled_by_default(false);
  sensor_sensor_id_74->set_icon("mdi:current-dc");
  sensor_sensor_id_74->set_device_class("current");
  sensor_sensor_id_74->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_74->set_unit_of_measurement("A");
  sensor_sensor_id_74->set_accuracy_decimals(2);
  sensor_sensor_id_74->set_force_update(false);
  bms0->set_balancing_current_sensor(sensor_sensor_id_74);
  sensor_sensor_id_75 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_75);
  sensor_sensor_id_75->set_name("jk-bms errors bitmask");
  sensor_sensor_id_75->set_object_id("jk-bms_errors_bitmask");
  sensor_sensor_id_75->set_disabled_by_default(false);
  sensor_sensor_id_75->set_icon("mdi:alert-circle-outline");
  sensor_sensor_id_75->set_device_class("");
  sensor_sensor_id_75->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_75->set_unit_of_measurement("");
  sensor_sensor_id_75->set_accuracy_decimals(0);
  sensor_sensor_id_75->set_force_update(false);
  bms0->set_errors_bitmask_sensor(sensor_sensor_id_75);
  sensor_sensor_id_76 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_76);
  sensor_sensor_id_76->set_name("jk-bms emergency time countdown");
  sensor_sensor_id_76->set_object_id("jk-bms_emergency_time_countdown");
  sensor_sensor_id_76->set_disabled_by_default(false);
  sensor_sensor_id_76->set_icon("mdi:timelapse");
  sensor_sensor_id_76->set_device_class("");
  sensor_sensor_id_76->set_unit_of_measurement("s");
  sensor_sensor_id_76->set_accuracy_decimals(0);
  sensor_sensor_id_76->set_force_update(false);
  bms0->set_emergency_time_countdown_sensor(sensor_sensor_id_76);
  sensor_sensor_id_57 = new sensor::Sensor();
  App.register_sensor(sensor_sensor_id_57);
  sensor_sensor_id_57->set_name("jk-bms heating current");
  sensor_sensor_id_57->set_object_id("jk-bms_heating_current");
  sensor_sensor_id_57->set_disabled_by_default(false);
  sensor_sensor_id_57->set_icon("mdi:current-dc");
  sensor_sensor_id_57->set_device_class("current");
  sensor_sensor_id_57->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  sensor_sensor_id_57->set_unit_of_measurement("A");
  sensor_sensor_id_57->set_accuracy_decimals(2);
  sensor_sensor_id_57->set_force_update(false);
  bms0->set_heating_current_sensor(sensor_sensor_id_57);
  // switch.jk_bms_ble:
  //   platform: jk_bms_ble
  //   charging:
  //     name: jk-bms charging
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id
  //     icon: mdi:battery-charging-50
  //   discharging:
  //     name: jk-bms discharging
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_2
  //     icon: mdi:battery-charging-50
  //   balancer:
  //     name: jk-bms balancer
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_3
  //     icon: mdi:seesaw
  //   emergency:
  //     name: jk-bms emergency
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_4
  //     icon: mdi:exit-run
  //   heating:
  //     name: jk-bms heating
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_5
  //     icon: mdi:radiator
  //   disable_temperature_sensors:
  //     name: jk-bms disable temperature sensors
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_6
  //     icon: mdi:thermometer-off
  //   display_always_on:
  //     name: jk-bms display always on
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_7
  //     icon: mdi:television
  //   smart_sleep:
  //     name: jk-bms smart sleep
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_8
  //     icon: mdi:sleep
  //   disable_pcl_module:
  //     name: jk-bms disable pcl module
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_9
  //     icon: mdi:power-plug-off
  //   timed_stored_data:
  //     name: jk-bms timed stored data
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_10
  //     icon: mdi:calendar-clock
  //   charging_float_mode:
  //     name: jk-bms charging float mode
  //     disabled_by_default: false
  //     restore_mode: ALWAYS_OFF
  //     id: jk_bms_ble_jkswitch_id_11
  //     icon: mdi:battery-charging-80
  //   jk_bms_ble_id: bms0
  jk_bms_ble_jkswitch_id = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id);
  App.register_switch(jk_bms_ble_jkswitch_id);
  jk_bms_ble_jkswitch_id->set_name("jk-bms charging");
  jk_bms_ble_jkswitch_id->set_object_id("jk-bms_charging");
  jk_bms_ble_jkswitch_id->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id->set_icon("mdi:battery-charging-50");
  jk_bms_ble_jkswitch_id->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_charging_switch(jk_bms_ble_jkswitch_id);
  jk_bms_ble_jkswitch_id->set_parent(bms0);
  jk_bms_ble_jkswitch_id->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id->set_jk02_holding_register(29);
  jk_bms_ble_jkswitch_id->set_jk02_32s_holding_register(29);
  jk_bms_ble_jkswitch_id_2 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_2->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_2);
  App.register_switch(jk_bms_ble_jkswitch_id_2);
  jk_bms_ble_jkswitch_id_2->set_name("jk-bms discharging");
  jk_bms_ble_jkswitch_id_2->set_object_id("jk-bms_discharging");
  jk_bms_ble_jkswitch_id_2->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_2->set_icon("mdi:battery-charging-50");
  jk_bms_ble_jkswitch_id_2->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_discharging_switch(jk_bms_ble_jkswitch_id_2);
  jk_bms_ble_jkswitch_id_2->set_parent(bms0);
  jk_bms_ble_jkswitch_id_2->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_2->set_jk02_holding_register(30);
  jk_bms_ble_jkswitch_id_2->set_jk02_32s_holding_register(30);
  jk_bms_ble_jkswitch_id_3 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_3->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_3);
  App.register_switch(jk_bms_ble_jkswitch_id_3);
  jk_bms_ble_jkswitch_id_3->set_name("jk-bms balancer");
  jk_bms_ble_jkswitch_id_3->set_object_id("jk-bms_balancer");
  jk_bms_ble_jkswitch_id_3->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_3->set_icon("mdi:seesaw");
  jk_bms_ble_jkswitch_id_3->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_balancer_switch(jk_bms_ble_jkswitch_id_3);
  jk_bms_ble_jkswitch_id_3->set_parent(bms0);
  jk_bms_ble_jkswitch_id_3->set_jk04_holding_register(108);
  jk_bms_ble_jkswitch_id_3->set_jk02_holding_register(31);
  jk_bms_ble_jkswitch_id_3->set_jk02_32s_holding_register(31);
  jk_bms_ble_jkswitch_id_4 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_4->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_4);
  App.register_switch(jk_bms_ble_jkswitch_id_4);
  jk_bms_ble_jkswitch_id_4->set_name("jk-bms emergency");
  jk_bms_ble_jkswitch_id_4->set_object_id("jk-bms_emergency");
  jk_bms_ble_jkswitch_id_4->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_4->set_icon("mdi:exit-run");
  jk_bms_ble_jkswitch_id_4->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_emergency_switch(jk_bms_ble_jkswitch_id_4);
  jk_bms_ble_jkswitch_id_4->set_parent(bms0);
  jk_bms_ble_jkswitch_id_4->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_4->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_4->set_jk02_32s_holding_register(107);
  jk_bms_ble_jkswitch_id_5 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_5->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_5);
  App.register_switch(jk_bms_ble_jkswitch_id_5);
  jk_bms_ble_jkswitch_id_5->set_name("jk-bms heating");
  jk_bms_ble_jkswitch_id_5->set_object_id("jk-bms_heating");
  jk_bms_ble_jkswitch_id_5->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_5->set_icon("mdi:radiator");
  jk_bms_ble_jkswitch_id_5->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_heating_switch(jk_bms_ble_jkswitch_id_5);
  jk_bms_ble_jkswitch_id_5->set_parent(bms0);
  jk_bms_ble_jkswitch_id_5->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_5->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_5->set_jk02_32s_holding_register(39);
  jk_bms_ble_jkswitch_id_6 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_6->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_6);
  App.register_switch(jk_bms_ble_jkswitch_id_6);
  jk_bms_ble_jkswitch_id_6->set_name("jk-bms disable temperature sensors");
  jk_bms_ble_jkswitch_id_6->set_object_id("jk-bms_disable_temperature_sensors");
  jk_bms_ble_jkswitch_id_6->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_6->set_icon("mdi:thermometer-off");
  jk_bms_ble_jkswitch_id_6->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_disable_temperature_sensors_switch(jk_bms_ble_jkswitch_id_6);
  jk_bms_ble_jkswitch_id_6->set_parent(bms0);
  jk_bms_ble_jkswitch_id_6->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_6->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_6->set_jk02_32s_holding_register(40);
  jk_bms_ble_jkswitch_id_7 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_7->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_7);
  App.register_switch(jk_bms_ble_jkswitch_id_7);
  jk_bms_ble_jkswitch_id_7->set_name("jk-bms display always on");
  jk_bms_ble_jkswitch_id_7->set_object_id("jk-bms_display_always_on");
  jk_bms_ble_jkswitch_id_7->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_7->set_icon("mdi:television");
  jk_bms_ble_jkswitch_id_7->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_display_always_on_switch(jk_bms_ble_jkswitch_id_7);
  jk_bms_ble_jkswitch_id_7->set_parent(bms0);
  jk_bms_ble_jkswitch_id_7->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_7->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_7->set_jk02_32s_holding_register(43);
  jk_bms_ble_jkswitch_id_8 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_8->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_8);
  App.register_switch(jk_bms_ble_jkswitch_id_8);
  jk_bms_ble_jkswitch_id_8->set_name("jk-bms smart sleep");
  jk_bms_ble_jkswitch_id_8->set_object_id("jk-bms_smart_sleep");
  jk_bms_ble_jkswitch_id_8->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_8->set_icon("mdi:sleep");
  jk_bms_ble_jkswitch_id_8->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_smart_sleep_switch(jk_bms_ble_jkswitch_id_8);
  jk_bms_ble_jkswitch_id_8->set_parent(bms0);
  jk_bms_ble_jkswitch_id_8->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_8->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_8->set_jk02_32s_holding_register(45);
  jk_bms_ble_jkswitch_id_9 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_9->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_9);
  App.register_switch(jk_bms_ble_jkswitch_id_9);
  jk_bms_ble_jkswitch_id_9->set_name("jk-bms disable pcl module");
  jk_bms_ble_jkswitch_id_9->set_object_id("jk-bms_disable_pcl_module");
  jk_bms_ble_jkswitch_id_9->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_9->set_icon("mdi:power-plug-off");
  jk_bms_ble_jkswitch_id_9->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_disable_pcl_module_switch(jk_bms_ble_jkswitch_id_9);
  jk_bms_ble_jkswitch_id_9->set_parent(bms0);
  jk_bms_ble_jkswitch_id_9->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_9->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_9->set_jk02_32s_holding_register(46);
  jk_bms_ble_jkswitch_id_10 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_10->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_10);
  App.register_switch(jk_bms_ble_jkswitch_id_10);
  jk_bms_ble_jkswitch_id_10->set_name("jk-bms timed stored data");
  jk_bms_ble_jkswitch_id_10->set_object_id("jk-bms_timed_stored_data");
  jk_bms_ble_jkswitch_id_10->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_10->set_icon("mdi:calendar-clock");
  jk_bms_ble_jkswitch_id_10->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_timed_stored_data_switch(jk_bms_ble_jkswitch_id_10);
  jk_bms_ble_jkswitch_id_10->set_parent(bms0);
  jk_bms_ble_jkswitch_id_10->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_10->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_10->set_jk02_32s_holding_register(47);
  jk_bms_ble_jkswitch_id_11 = new jk_bms_ble::JkSwitch();
  jk_bms_ble_jkswitch_id_11->set_component_source("jk_bms_ble.switch");
  App.register_component(jk_bms_ble_jkswitch_id_11);
  App.register_switch(jk_bms_ble_jkswitch_id_11);
  jk_bms_ble_jkswitch_id_11->set_name("jk-bms charging float mode");
  jk_bms_ble_jkswitch_id_11->set_object_id("jk-bms_charging_float_mode");
  jk_bms_ble_jkswitch_id_11->set_disabled_by_default(false);
  jk_bms_ble_jkswitch_id_11->set_icon("mdi:battery-charging-80");
  jk_bms_ble_jkswitch_id_11->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  bms0->set_charging_float_mode_switch(jk_bms_ble_jkswitch_id_11);
  jk_bms_ble_jkswitch_id_11->set_parent(bms0);
  jk_bms_ble_jkswitch_id_11->set_jk04_holding_register(0);
  jk_bms_ble_jkswitch_id_11->set_jk02_holding_register(0);
  jk_bms_ble_jkswitch_id_11->set_jk02_32s_holding_register(48);
  // switch.ble_client:
  //   platform: ble_client
  //   ble_client_id: client0
  //   id: ble_client_switch0
  //   name: jk-bms enable bluetooth connection
  //   disabled_by_default: false
  //   restore_mode: ALWAYS_OFF
  //   icon: mdi:bluetooth
  ble_client_switch0 = new ble_client::BLEClientSwitch();
  App.register_switch(ble_client_switch0);
  ble_client_switch0->set_name("jk-bms enable bluetooth connection");
  ble_client_switch0->set_object_id("jk-bms_enable_bluetooth_connection");
  ble_client_switch0->set_disabled_by_default(false);
  ble_client_switch0->set_icon("mdi:bluetooth");
  ble_client_switch0->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  ble_client_switch0->set_component_source("ble_client.switch");
  App.register_component(ble_client_switch0);
  client0->register_ble_node(ble_client_switch0);
  // text_sensor.jk_bms_ble:
  //   platform: jk_bms_ble
  //   errors:
  //     name: jk-bms errors
  //     disabled_by_default: false
  //     id: text_sensor_textsensor_id
  //     icon: mdi:alert-circle-outline
  //   total_runtime_formatted:
  //     name: jk-bms total runtime formatted
  //     disabled_by_default: false
  //     id: text_sensor_textsensor_id_2
  //     icon: mdi:timelapse
  //   jk_bms_ble_id: bms0
  text_sensor_textsensor_id = new text_sensor::TextSensor();
  App.register_text_sensor(text_sensor_textsensor_id);
  text_sensor_textsensor_id->set_name("jk-bms errors");
  text_sensor_textsensor_id->set_object_id("jk-bms_errors");
  text_sensor_textsensor_id->set_disabled_by_default(false);
  text_sensor_textsensor_id->set_icon("mdi:alert-circle-outline");
  bms0->set_errors_text_sensor(text_sensor_textsensor_id);
  text_sensor_textsensor_id_2 = new text_sensor::TextSensor();
  App.register_text_sensor(text_sensor_textsensor_id_2);
  text_sensor_textsensor_id_2->set_name("jk-bms total runtime formatted");
  text_sensor_textsensor_id_2->set_object_id("jk-bms_total_runtime_formatted");
  text_sensor_textsensor_id_2->set_disabled_by_default(false);
  text_sensor_textsensor_id_2->set_icon("mdi:timelapse");
  bms0->set_total_runtime_formatted_text_sensor(text_sensor_textsensor_id_2);
  // network:
  //   enable_ipv6: false
  //   min_ipv6_addr_count: 0
  // md5:
  // socket:
  //   implementation: bsd_sockets
  // esp32_ble:
  //   id: esp32_ble_esp32ble_id
  //   io_capability: none
  //   enable_on_boot: true
  //   advertising_cycle_time: 10s
  esp32_ble_esp32ble_id = new esp32_ble::ESP32BLE();
  esp32_ble_esp32ble_id->set_enable_on_boot(true);
  esp32_ble_esp32ble_id->set_io_capability(esp32_ble::IO_CAP_NONE);
  esp32_ble_esp32ble_id->set_advertising_cycle_time(10000);
  esp32_ble_esp32ble_id->set_component_source("esp32_ble");
  App.register_component(esp32_ble_esp32ble_id);
  switch__turnoffaction_id = new switch_::TurnOffAction<>(ble_client_switch0);
  lambdaaction_id = new LambdaAction<>([=]() -> void {
      ESP_LOGD("main", "BLE connection suspended for OTA update");
  });
  automation_id->add_actions({switch__turnoffaction_id, lambdaaction_id});
  esp32_ble_esp32ble_id->register_gap_event_handler(esp32_ble_tracker_esp32bletracker_id);
  esp32_ble_esp32ble_id->register_gattc_event_handler(esp32_ble_tracker_esp32bletracker_id);
  esp32_ble_esp32ble_id->register_ble_status_event_handler(esp32_ble_tracker_esp32bletracker_id);
  esp32_ble_tracker_esp32bletracker_id->set_parent(esp32_ble_esp32ble_id);
  esp32_ble_tracker_esp32bletracker_id->set_scan_duration(300);
  esp32_ble_tracker_esp32bletracker_id->set_scan_interval(512);
  esp32_ble_tracker_esp32bletracker_id->set_scan_window(48);
  esp32_ble_tracker_esp32bletracker_id->set_scan_active(false);
  esp32_ble_tracker_esp32bletracker_id->set_scan_continuous(true);
  // =========== AUTO GENERATED CODE END ============
  App.setup();
}

void loop() {
  App.loop();
}
