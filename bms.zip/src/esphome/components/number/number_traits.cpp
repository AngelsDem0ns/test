#include "esphome/core/log.h"
#include "number_traits.h"

namespace esphome {
namespace number {

static const char *const TAG = "number";

}  // namespace number
}  // namespace esphome
