#pragma once
#include "esphome/core/macros.h"
#define ESPHOME_BOARD "esp32dev"
#define ESPHOME_PROJECT_NAME "syssi.esphome-jk-bms"
#define ESPHOME_PROJECT_VERSION "2.1.0"
#define ESPHOME_PROJECT_VERSION_30 "2.1.0"
#define ESPHOME_VARIANT "ESP32"
#define USE_API
#define USE_API_NOISE
#define USE_ARDUINO_VERSION_CODE VERSION_CODE(2, 0, 5)
#define USE_BINARY_SENSOR
#define USE_BUTTON
#define USE_ESP32_BLE
#define USE_ESP32_BLE_CLIENT
#define USE_LOGGER
#define USE_MD5
#define USE_MDNS
#define USE_NETWORK
#define USE_NETWORK_IPV6 false
#define USE_NUMBER
#define USE_OTA
#define USE_OTA_STATE_CALLBACK
#define USE_OTA_VERSION 2
#define USE_SENSOR
#define USE_SOCKET_IMPL_BSD_SOCKETS
#define USE_SWITCH
#define USE_TEXT_SENSOR
#define USE_WIFI
