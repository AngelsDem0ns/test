#pragma once
#include "esphome/core/macros.h"
#define ESPHOME_VERSION "2025.4.0"
#define ESPHOME_VERSION_CODE VERSION_CODE(2025, 4, 0)
